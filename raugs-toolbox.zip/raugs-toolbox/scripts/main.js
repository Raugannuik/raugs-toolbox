// scripts/main.js - Raug's Toolkit (Foundry v13 / dnd5e 5.3.3 AppV2 Engine)
"use strict";

import { RAUG_MODULE_ID, RAUG_TAB_IDLE, RAUG_TAB_ACTIVE, getRaugTrayState, setRaugTrayState } from "./modules/state.js";
import { registerAllWrappers, handleConsumableUseViaWrapper } from "./modules/intercepts.js";
import { buildCombatTestRow, runRaugSpellcastingButtonMenu } from "./modules/paneCombat.js";
import { buildClassAbilitiesPane } from "./modules/paneAbilities.js";
import { buildConsumablesHubPane, runGlobalInventoryAudit } from "./modules/paneConsumables.js";
import { buildCombatBreakdownPane } from "./modules/paneTracker.js";
import { buildMacroPane } from "./modules/paneMacros.js";
import { buildNpcPane } from "./modules/paneNPC.js";
import { handleWildShapeUseViaWrapper } from "./modules/wildShapeUI.js";
import { promptExtraDamageIfEligible } from "./modules/extraDamageUI.js";
import "./modules/sheetMinimizer.js";

// Helper to differentiate unlinked token actors on the map (SyntheticActors) vs base sidebar actors
function getUniqueActorKey(actor) {
    return actor?.uuid || actor?.id || "unknown";
}

Hooks.once("init", () => {
    console.log("Raug's Toolkit | Initializing Modular Engine Frame for Foundry V13 & dnd5e 5.x");
});

Hooks.once("ready", async () => {
    if (typeof libWrapper === "undefined") {
        console.error("Raug's Toolkit | libWrapper is required. Please enable lib-wrapper.");
        return;
    }

    registerAllWrappers();

    // --- 1. ITEM USE WRAPPER (Consumables, Wild Shape) ---
    try {
        const itemUseTarget = "CONFIG.Item.documentClass.prototype.use";
        
        libWrapper.register(RAUG_MODULE_ID, itemUseTarget, async function (wrapped, ...args) {
            const item = this;
            const actor = item?.actor || null;
            const cleanName = item?.name?.toLowerCase() || "";

            if (actor && (cleanName.includes("wild shape") || cleanName.includes("wild resurgence"))) {
                return await handleWildShapeUseViaWrapper(wrapped, item, args);
            }

            try {
                if (item?.type === "consumable") {
                    this._raug_preUseQuantity = Number(this.system?.quantity ?? this.system?.uses?.value ?? NaN);
                }
            } catch (e) { /* ignore */ }

            const result = await wrapped.apply(this, args);

            try {
                if (item?.type === "consumable") {
                    await handleConsumableUseViaWrapper(actor, item, result);
                }
            } catch (err) {
                console.error("RaugToolkit consumable wrapper error", err);
            }

            return result;
        }, "MIXED");
    } catch (err) {
        console.error("Raug's Toolkit | Failed to register Item.use wrapper", err);
    }

    // --- 2. SAFE EXTRA DAMAGE HOOK ON DAMAGE ROLL ---
    // Listens directly to dnd5e system damage rolls (works with both sheet clicks and chat card buttons)
    Hooks.on("dnd5e.rollDamage", async (item, rollConfig) => {
        try {
            const actor = item?.actor;
            if (actor) {
                await promptExtraDamageIfEligible(actor, item);
            }
        } catch (err) {
            console.error("RaugToolkit damage hook error", err);
        }
    });

    // Fallback hook for Activity-based system damage calls
    Hooks.on("dnd5e.postRollDamage", async (item, roll) => {
        try {
            const actor = item?.actor || item?.item?.actor;
            if (actor) {
                await promptExtraDamageIfEligible(actor, item);
            }
        } catch (err) {
            console.error("RaugToolkit postRollDamage hook error", err);
        }
    });

    Hooks.on("updateActor", (actor) => {
        try { rebuildTrayForActor(actor); } catch (e) { /* silent */ }
    });
});

// -------------------------------------------------------------
// V13 / dnd5e 5.3.3 APPV2 DIRECT WINDOW MOUNTING PIPELINE
// -------------------------------------------------------------
function injectRaugTrayV13(app, html) {
    try {
        const actor = app?.actor || app?.document;
        if (!actor || actor.documentName !== "Actor") return;

        const rootElement = app?.element?.[0] || app?.element || (html instanceof HTMLElement ? html : html?.[0]);
        if (!rootElement) return;

        const targetContainer = rootElement.querySelector(".window-content") 
                             || rootElement.closest(".window-app, .application") 
                             || rootElement;

        setTimeout(() => {
            buildAndAppendMasterTray(actor, targetContainer);
        }, 50);
    } catch (err) {
        console.warn("RaugToolkit: V13 Sheet Injection Error", err);
    }
}

Hooks.on("renderActorSheet", (app, html) => injectRaugTrayV13(app, html));
Hooks.on("renderActorSheetV2", (app, html) => injectRaugTrayV13(app, html));
Hooks.on("renderApplication", (app, html) => {
    if (app?.document?.documentName === "Actor" || app?.actor) injectRaugTrayV13(app, html);
});

export function refreshRaugTrayForActor(actor) {
    try {
        const uniqueKey = getUniqueActorKey(actor);
        document.querySelectorAll(`[data-raug-key="${uniqueKey}"], [data-actor-id="${actor.id}"]`).forEach(el => {
            const targetContainer = el.querySelector(".window-content") || el;
            buildAndAppendMasterTray(actor, targetContainer);
        });
    } catch (err) {
        console.warn("RaugToolkit: refreshRaugTrayForActor failed", err);
    }
}

export function buildAndAppendMasterTray(actor, footerElement) {
    if (!actor || !footerElement) return;

    // Scope check ONLY within this specific sheet window element to prevent touching other open sheets
    const existing = footerElement.querySelector(".raug-master-toolbox-panel");
    if (existing) existing.remove();

    const isNpc = actor.type === "npc";
    const uniqueKey = getUniqueActorKey(actor);
    const state = getRaugTrayState(uniqueKey);
    
    const masterPanel = document.createElement("section");
    masterPanel.className = "raug-master-toolbox-panel";
    masterPanel.dataset.raugKey = uniqueKey;
    masterPanel.dataset.actorId = actor.id;
    masterPanel.style.cssText = "display:block !important; visibility:visible !important; margin:10px 0 !important; padding:10px !important; border:1px solid rgba(201,176,122,0.4) !important; border-radius:5px !important; background:#1a1a1a !important; font-family:sans-serif !important; color:#d6d6d6 !important; width:100% !important; box-sizing:border-box !important; clear:both !important; flex-shrink:0 !important; z-index:100 !important; min-height:35px !important;";
    
    const headerTitle = isNpc ? "NPC Combat Utility" : "Raug's Integrated Utility Tray";
    const headerIcon = isNpc ? "fa-dragon" : "fa-toolbox";

    let drawerHtml = "";

    if (isNpc) {
        drawerHtml = `<div class="raug-npc-pane-root"></div>`;
    } else {
        drawerHtml = `
            <nav class="raug-footer-tabs" style="display:flex; gap:4px; margin-bottom:8px; border-bottom:1px solid #444; padding-bottom:4px;">
                <button type="button" class="raug-subtab-btn" data-subtab="combat" style="${RAUG_TAB_IDLE}">Combat/Spells</button>
                <button type="button" class="raug-subtab-btn" data-subtab="abilities" style="${RAUG_TAB_IDLE}">Class Abilities</button>
                <button type="button" class="raug-subtab-btn" data-subtab="consumables" style="${RAUG_TAB_IDLE}">Consumables</button>
                <button type="button" class="raug-subtab-btn" data-subtab="utility" style="${RAUG_TAB_IDLE}">Session Tracker</button>
                <button type="button" class="raug-subtab-btn" data-subtab="macros" style="${RAUG_TAB_IDLE}">Macros</button>
            </nav>
            <div class="raug-pane-combat raug-subtab-pane" style="display:none;"></div>
            <div class="raug-pane-abilities raug-subtab-pane" style="display:none;"></div>
            <div class="raug-pane-consumables raug-subtab-pane" style="display:none;"></div>
            <div class="raug-pane-utility raug-subtab-pane" style="display:none;"></div>
            <div class="raug-pane-macros raug-subtab-pane" style="display:none;"></div>
        `;
    }

    masterPanel.innerHTML = `
        <header style="font-size:13px; font-weight:bold; color:#c9b07a; padding-bottom:3px; cursor:pointer;" class="raug-panel-toggle">
            <i class="fas ${headerIcon}"></i> ${headerTitle}
            <span style="font-size:9px; float:right; color:#888;" class="raug-toggle-text">${state.expanded ? "(Click to Collapse View)" : "(Click to Expand View)"}</span>
        </header>
        <div class="raug-panel-drawer" style="display:${state.expanded ? "block" : "none"}; width:100%; margin-top:8px; border-top:1px solid rgba(201,176,122,0.15); padding-top:8px;">
            ${drawerHtml}
        </div>
    `;
    
    footerElement.appendChild(masterPanel);

    masterPanel.querySelector(".raug-panel-toggle").addEventListener("click", () => {
        const drawer = masterPanel.querySelector(".raug-panel-drawer");
        const toggleText = masterPanel.querySelector(".raug-toggle-text");
        const isHidden = drawer.style.display === "none";
        drawer.style.display = isHidden ? "block" : "none";
        toggleText.textContent = isHidden ? "(Click to Collapse View)" : "(Click to Expand View)";
        setRaugTrayState(uniqueKey, { expanded: isHidden });
    });

    if (isNpc) {
        buildNpcPane(actor, masterPanel.querySelector(".raug-npc-pane-root"));
    } else {
        setupTrayInteractionListeners(actor, masterPanel);
        applyRaugTrayTab(masterPanel, state.tab || "combat");
    }
}

function applyRaugTrayTab(masterPanel, targetSubTab) {
    const subTabButtons = masterPanel.querySelectorAll(".raug-subtab-btn");
    const subTabPanes = masterPanel.querySelectorAll(".raug-subtab-pane");
    subTabButtons.forEach(b => { b.style.cssText = RAUG_TAB_IDLE; });
    subTabPanes.forEach(pane => { pane.style.display = "none"; });
    const activeBtn = masterPanel.querySelector(`.raug-subtab-btn[data-subtab="${targetSubTab}"]`);
    const activePane = masterPanel.querySelector(`.raug-pane-${targetSubTab}`);
    if (activeBtn) activeBtn.style.cssText = RAUG_TAB_ACTIVE;
    if (activePane) activePane.style.display = "block";
}

function setupTrayInteractionListeners(actor, masterPanel) {
    const uniqueKey = getUniqueActorKey(actor);
    masterPanel.querySelectorAll(".raug-subtab-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            const targetSubTab = btn.getAttribute("data-subtab");
            applyRaugTrayTab(masterPanel, targetSubTab);
            setRaugTrayState(uniqueKey, { tab: targetSubTab });
        });
    });

    buildCombatTestRow(actor, masterPanel.querySelector(".raug-pane-combat"));
    buildClassAbilitiesPane(actor, masterPanel.querySelector(".raug-pane-abilities"));
    buildConsumablesHubPane(actor, masterPanel.querySelector(".raug-pane-consumables"));
    buildCombatBreakdownPane(actor, masterPanel.querySelector(".raug-pane-utility"));
    buildMacroPane(actor, masterPanel.querySelector(".raug-pane-macros"));
}

export function rebuildTrayForActor(actor) {
    if (!actor) return;
    refreshRaugTrayForActor(actor);
}

window.buildAndAppendMasterTray = buildAndAppendMasterTray;
window.rebuildTrayForActor = rebuildTrayForActor;
window.runGlobalInventoryAudit = runGlobalInventoryAudit;
window.runRaugSpellcastingButtonMenu = runRaugSpellcastingButtonMenu;

console.log("Raug's Toolkit | ES Modules loaded successfully.");