// scripts/modules/paneAbilities.js
"use strict";

import { RAUG_CAT_BTN } from "./state.js";

/**
 * Main export expected by main.js
 */
export function buildClassAbilitiesPane(actor, container) {
    if (!container) return;

    container.innerHTML = `
        <strong style="color:#c9b07a; font-size:11px; display:block; margin-bottom:6px; font-weight:bold;">
            <i class="fas fa-bolt"></i> Class Abilities & Features
        </strong>
        <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:6px; padding:2px;">
            <button type="button" id="raug-features-btn" style="${RAUG_CAT_BTN}">
                <i class="fas fa-shield-halved"></i> Class Features
            </button>
            <button type="button" id="raug-passives-btn" style="${RAUG_CAT_BTN}">
                <i class="fas fa-award"></i> Passives & Traits
            </button>
        </div>
        <div id="raug-abilities-dynamic-host" style="margin-top:8px;"></div>
    `;

    const dynamicHost = container.querySelector("#raug-abilities-dynamic-host");

    const featuresBtn = container.querySelector("#raug-features-btn");
    if (featuresBtn) {
        featuresBtn.onclick = () => {
            runRaugFeaturesButtonMenu(actor);
        };
    }

    const passivesBtn = container.querySelector("#raug-passives-btn");
    if (passivesBtn) {
        passivesBtn.onclick = () => {
            renderPassivesEngineMenu(actor, dynamicHost);
        };
    }
}

export function runRaugFeaturesButtonMenu(actor) {
    if (!actor) return;

    const features = actor.items.filter(i => i.type === "feat");

    if (!features.length) {
        return ui.notifications.info(`${actor.name} has no class features or abilities.`);
    }

    const featuresByActivation = {};
    features.forEach(feat => {
        const type = feat.system?.activation?.type || "passive";
        if (!featuresByActivation[type]) featuresByActivation[type] = [];
        featuresByActivation[type].push(feat);
    });

    let dialogContent = `
        <div style="
            font-family: var(--font-primary, 'Signika', sans-serif); 
            max-height: 420px; 
            overflow-y: auto; 
            padding: 8px 12px;
            color: #191813;
        ">
    `;

    Object.keys(featuresByActivation).sort().forEach(type => {
        const label = type.charAt(0).toUpperCase() + type.slice(1);

        dialogContent += `
            <div style="
                font-family: var(--font-header, 'Modesto Condensed', 'Palatino Linotype', serif);
                font-size: 15px; 
                font-weight: bold; 
                color: #4a0000; 
                margin-top: 10px; 
                margin-bottom: 6px; 
                border-bottom: 2px solid #7a7971; 
                padding-bottom: 2px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            ">
                ${label} Actions
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 6px; margin-bottom: 10px;">
        `;

        featuresByActivation[type].forEach(feat => {
            dialogContent += `
                <button type="button" class="raug-dialog-ability-btn" data-item-id="${feat.id}" style="
                    background: linear-gradient(to bottom, #f7f3e8 0%, #eadabe 100%);
                    color: #191813;
                    border: 1px solid #b5a48b;
                    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.4), 0 1px 2px rgba(0,0,0,0.15);
                    font-size: 11px;
                    font-weight: 600;
                    padding: 5px 8px;
                    border-radius: 3px;
                    cursor: pointer;
                    text-align: left;
                    display: flex;
                    align-items: center;
                    transition: all 0.15s ease-in-out;
                ">
                    <img src="${feat.img}" style="width: 16px; height: 16px; margin-right: 6px; border: 1px solid #999; border-radius: 2px; flex-shrink: 0; object-fit: cover;"/>
                    <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${feat.name}</span>
                </button>
            `;
        });

        dialogContent += `</div>`;
    });

    dialogContent += `</div>`;

    const d = new Dialog({
        title: `Abilities: ${actor.name}`,
        content: dialogContent,
        buttons: {
            close: {
                label: "Close",
                icon: '<i class="fas fa-times"></i>'
            }
        },
        default: "close",
        render: (html) => {
            const root = html instanceof HTMLElement ? html : html[0];
            
            root.querySelectorAll(".raug-dialog-ability-btn").forEach(btn => {
                btn.addEventListener("mouseenter", () => {
                    btn.style.background = "linear-gradient(to bottom, #fffdf8 0%, #f3e5c8 100%)";
                    btn.style.borderColor = "#7a0000";
                    btn.style.color = "#7a0000";
                });
                btn.addEventListener("mouseleave", () => {
                    btn.style.background = "linear-gradient(to bottom, #f7f3e8 0%, #eadabe 100%)";
                    btn.style.borderColor = "#b5a48b";
                    btn.style.color = "#191813";
                });

                btn.onclick = async () => {
                    const itemId = btn.dataset.itemId;
                    const feat = actor.items.get(itemId);
                    
                    d.close();

                    if (!feat) return;

                    if (typeof feat.use === "function") {
                        await feat.use();
                    } else if (typeof feat.roll === "function") {
                        await feat.roll();
                    } else {
                        ui.notifications.warn(`Cannot use ability: ${feat.name}`);
                    }
                };
            });
        }
    }, { 
        width: 500,
        classes: ["dnd5e2", "sheet", "raug-ability-popup"]
    });

    d.render(true);
}

export function renderPassivesEngineMenu(actor, hostElement) {
    if (!actor || !hostElement) return;

    const passives = actor.items.filter(i => i.type === "feat" && !i.system?.activation?.type);

    if (!passives.length) {
        hostElement.innerHTML = `<div style="font-size:11px; color:#888; text-align:center; padding:6px;">No passive traits found on this sheet.</div>`;
        return;
    }

    let listHtml = `
        <div style="background:#111; border:1px solid #333; border-radius:4px; padding:6px; max-height:160px; overflow-y:auto;">
            <div style="font-size:10px; font-weight:bold; color:#c9b07a; margin-bottom:4px; border-bottom:1px solid #333; padding-bottom:2px;">Passive Features</div>
            <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap:4px;">
    `;

    passives.forEach(item => {
        listHtml += `
            <button type="button" class="raug-passive-item-btn" data-item-id="${item.id}" style="background:#222; color:#d6d6d6; border:1px solid #444; font-size:10px; padding:4px 6px; border-radius:3px; cursor:pointer; text-align:left; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;">
                <img src="${item.img}" style="width:12px; height:12px; vertical-align:middle; margin-right:4px; border:none;"/>
                ${item.name}
            </button>
        `;
    });

    listHtml += `</div></div>`;
    hostElement.innerHTML = listHtml;

    hostElement.querySelectorAll(".raug-passive-item-btn").forEach(btn => {
        btn.onclick = async () => {
            const itemId = btn.dataset.itemId;
            const item = actor.items.get(itemId);
            if (!item) return;

            if (typeof item.use === "function") {
                await item.use();
            } else {
                item.sheet.render(true);
            }
        };
    });
}