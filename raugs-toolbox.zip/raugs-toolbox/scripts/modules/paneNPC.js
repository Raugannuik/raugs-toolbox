// scripts/modules/paneNPC.js
"use strict";

import { raugDebugLog } from "./state.js";
import { MultiattackWizard } from "./multiAttackWizard.js";

function isLegendaryOrLair(item) {
    const featType = item.system?.type?.value || "";
    if (["legendary", "lair", "mythic"].includes(featType)) return true;

    const actType = item.system?.activation?.type || "";
    if (["legendary", "lair", "mythic"].includes(actType)) return true;

    const activities = item.system?.activities;
    if (activities) {
        const activityList = activities instanceof Map ? Array.from(activities.values()) : Object.values(activities);
        if (activityList.some(act => ["legendary", "lair", "mythic"].includes(act.activation?.type))) {
            return true;
        }
    }

    if (item.name.toLowerCase().includes("legendary action")) return true;

    return false;
}

const { DialogV2 } = foundry.applications.api;

class LegendaryDock extends DialogV2 {
    constructor(actor, legendaryItems, options = {}) {
        const content = LegendaryDock.buildContent(actor, legendaryItems);

        super({
            window: {
                title: `👑 Legendary Actions`,
                icon: "fas fa-crown",
                resizable: false
            },
            content: content,
            buttons: [
                {
                    action: "close",
                    label: "",
                    icon: ""
                }
            ],
            position: { width: 220, height: "auto" }
        }, options);

        this.actor = actor;
        this.legendaryItems = legendaryItems;
        this._hookId = null;
    }

    static DEFAULT_OPTIONS = {
        classes: ["dnd5e2", "sheet", "raug-legendary-dock-window"]
    };

    _onRender(context, options) {
        super._onRender(context, options);
        
        this.element.dataset.raugDock = "true";
        this.element.classList.add("raug-dock-isolated");

        this.element.style.background = "#141418";
        this.element.style.boxShadow = "0 0 10px rgba(0,0,0,0.8)";
        this.element.style.height = "auto";
        this.element.style.minHeight = "0px";
        
        const winHeader = this.element.querySelector(".window-header");
        if (winHeader) {
            winHeader.style.background = "linear-gradient(90deg, #2a1515 0%, #1a1a1e 100%)";
            winHeader.style.borderBottom = "1px solid #442222";
            winHeader.style.padding = "2px 6px";
            winHeader.style.minHeight = "22px";
            
            const title = winHeader.querySelector(".window-title");
            if (title) {
                title.style.fontSize = "11px";
                title.style.color = "#f2a4a4";
                title.style.fontWeight = "bold";
            }
        }

        const winContent = this.element.querySelector(".window-content");
        if (winContent) {
            winContent.style.padding = "4px";
            winContent.style.margin = "0px";
            winContent.style.background = "#141418";
            winContent.style.height = "auto";
            winContent.style.minHeight = "0px";
            winContent.style.maxHeight = "none";
        }

        const footer = this.element.querySelector("footer.form-footer, .dialog-buttons");
        if (footer) {
            footer.style.display = "none";
        }

        LegendaryDock.bindEvents(this.element, this, this.actor);

        // Listen for updates on the actor to update the legendary counter dynamically
        if (!this._hookId) {
            this._hookId = Hooks.on("updateActor", (updatedActor, changes) => {
                if (updatedActor.id !== this.actor.id) return;
                
                // Only update DOM if resource tracked values changed
                if (foundry.utils.hasProperty(changes, "system.resources.legact")) {
                    this.updateResourceDisplay();
                }
            });
        }
    }

    close(options = {}) {
        if (this._hookId) {
            Hooks.off("updateActor", this._hookId);
            this._hookId = null;
        }
        return super.close(options);
    }

    updateResourceDisplay() {
        const leg = this.actor.system?.resources?.legact || { value: 0, max: 0, spent: 0 };
        const max = leg.max || 0;
        const current = leg.spent !== undefined ? (max - leg.spent) : (leg.value || 0);

        const valDisplay = this.element.querySelector(".raug-dock-legact-val");
        if (valDisplay) {
            valDisplay.textContent = `${current} / ${max}`;
        }
    }

    static buildContent(actor, items) {
        const leg = actor.system?.resources?.legact || { value: 0, max: 0, spent: 0 };
        const max = leg.max || 0;
        const current = leg.spent !== undefined ? (max - leg.spent) : (leg.value || 0);

        let resourceTracker = "";
        if (max > 0) {
            resourceTracker = `
                <div style="display: flex; justify-content: space-between; align-items: center; background: #0c0c0e; padding: 3px 6px; border-radius: 3px; border: 1px solid #331818; margin-bottom: 3px;">
                    <span style="font-size: 10px; font-weight: bold; color: #e27474;">
                        <i class="fas fa-crown"></i> Actions
                    </span>
                    <span class="raug-dock-legact-val" style="font-size: 11px; font-weight: bold; color: #fff;">
                        ${current} / ${max}
                    </span>
                </div>
                <button type="button" class="raug-dock-reset-btn" style="
                    width: 100%; background: #261818; color: #f2a4a4; border: 1px solid #552222;
                    font-size: 9.5px; padding: 2px 4px; border-radius: 3px; cursor: pointer; text-align: center;
                    display: flex; align-items: center; justify-content: center; gap: 4px; font-weight: bold; margin-bottom: 4px;
                ">
                    <i class="fas fa-sync-alt" style="font-size: 9px;"></i>
                    <span>Reset Legendary Actions</span>
                </button>
            `;
        }

        const buttons = items.map(item => {
            const cost = item.system?.activation?.cost || 1;
            const costTag = cost > 1 ? `<span style="font-size: 9px; opacity: 0.7;">(${cost})</span>` : "";
            const rawDesc = item.system?.description?.value || "";
            const cleanDesc = clean5eDescriptionMarkup(rawDesc, actor);
            const descSnippet = cleanDesc ? `${cleanDesc.slice(0, 200)}${cleanDesc.length >= 200 ? "..." : ""}` : "No details.";

            const tooltipText = `
                <div style="text-align: left; max-width: 180px; font-size: 10.5px; line-height: 1.2;">
                    <strong style="color: #f2a4a4; font-size: 11px; display: block; border-bottom: 1px solid #555; padding-bottom: 2px; margin-bottom: 3px;">
                        ${item.name}
                    </strong>
                    <div style="color: #ddd;">${descSnippet}</div>
                </div>
            `.replace(/"/g, '&quot;');

            return `
                <button type="button" class="raug-dock-item-btn" data-item-id="${item.id}" data-tooltip="${tooltipText}" data-tooltip-direction="LEFT" style="
                    background: linear-gradient(90deg, #2a1515 0%, #1a1a1e 100%);
                    color: #f2a4a4; border: 1px solid #552222; font-size: 10px; padding: 3px 5px;
                    border-radius: 3px; cursor: pointer; text-align: left; display: flex; align-items: center;
                    gap: 5px; width: 100%; box-sizing: border-box; font-weight: bold; min-height: 22px;
                ">
                    <img src="${item.img || 'icons/svg/item-bag.svg'}" style="width: 13px; height: 13px; border: none; border-radius: 2px; flex-shrink: 0;" />
                    <span style="flex-grow: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${item.name}</span>
                    ${costTag}
                </button>
            `;
        }).join("");

        const rulesTooltip = `
            <div style="text-align: left; max-width: 200px; font-size: 10px; line-height: 1.2;">
                <strong style="color: #e27474; font-size: 11px; display: block; border-bottom: 1px solid #555; padding-bottom: 2px; margin-bottom: 3px;">
                    Legendary Actions
                </strong>
                Can only be used at the <strong>end of another creature's turn</strong>.<br/>
                Only <strong>one</strong> legendary action option can be used at a time.<br/>
                Spent legendary actions are <strong>regained at the start of its turn</strong>.
            </div>
        `.replace(/"/g, '&quot;');

        return `
            <div style="padding: 0px; font-family: sans-serif; width: 100%; box-sizing: border-box; background: #141418;">
                ${resourceTracker}
                <div style="display: flex; flex-direction: column; gap: 2px; max-height: 260px; overflow-y: auto; width: 100%; box-sizing: border-box;">
                    ${buttons}
                </div>
                <div style="display: flex; gap: 3px; margin-top: 4px;">
                    <button type="button" class="raug-dock-rules-btn" data-tooltip="${rulesTooltip}" data-tooltip-direction="UP" style="
                        flex: 2; background: #1c1c22; color: #888899; border: 1px solid #33333d;
                        font-size: 9.5px; padding: 2px 4px; border-radius: 3px; cursor: pointer; text-align: center;
                        display: flex; align-items: center; justify-content: center; gap: 4px; font-weight: bold;
                    ">
                        <i class="fas fa-question-circle" style="color: #888899;"></i>
                        <span>Legendary Rules</span>
                    </button>

                    <button type="button" class="raug-dock-close-btn" style="
                        flex: 1; background: #1c1c22; color: #e27474; border: 1px solid #442222;
                        font-size: 9.5px; padding: 2px 4px; border-radius: 3px; cursor: pointer; text-align: center;
                        display: flex; align-items: center; justify-content: center; gap: 3px; font-weight: bold;
                    ">
                        <i class="fas fa-times"></i>
                        <span>Close</span>
                    </button>
                </div>
            </div>
        `;
    }

    static bindEvents(root, appInstance, actor) {
        root.querySelectorAll(".raug-dock-item-btn").forEach(btn => {
            btn.onclick = async (e) => {
                e.preventDefault();
                const item = actor.items.get(btn.dataset.itemId);
                if (!item) return;

                raugDebugLog("Executing Legendary Action from Dock:", item.name);
                if (typeof item.use === "function") {
                    await item.use({}, { event: e });
                } else if (typeof item.roll === "function") {
                    await item.roll({ event: e });
                } else {
                    item.sheet?.render(true);
                }
            };

            btn.oncontextmenu = (e) => {
                e.preventDefault();
                const item = actor.items.get(btn.dataset.itemId);
                item?.sheet?.render(true);
            };
        });

        const resetBtn = root.querySelector(".raug-dock-reset-btn");
        if (resetBtn) {
            resetBtn.onclick = async (e) => {
                e.preventDefault();

                const leg = actor.system?.resources?.legact || {};
                const updates = {};

                if (leg.spent !== undefined) {
                    updates["system.resources.legact.spent"] = 0;
                } else if (leg.max !== undefined) {
                    updates["system.resources.legact.value"] = leg.max;
                }

                if (Object.keys(updates).length > 0) {
                    await actor.update(updates);
                }
            };
        }

        const closeBtn = root.querySelector(".raug-dock-close-btn");
        if (closeBtn) {
            closeBtn.onclick = (e) => {
                e.preventDefault();
                appInstance.close();
            };
        }

        const rulesBtn = root.querySelector(".raug-dock-rules-btn");
        if (rulesBtn) {
            rulesBtn.onclick = async (e) => {
                e.preventDefault();
                
                const cardContent = `
                    <div class="dnd5e2 chat-card item-card" style="background: #fdf1dc; border: 1px solid #c9b79c; border-radius: 4px; padding: 6px; font-family: 'Signika', sans-serif; color: #191813;">
                        <header class="card-header flexrow" style="border-bottom: 2px solid #7a2021; margin-bottom: 6px; padding-bottom: 4px; display: flex; align-items: center; gap: 6px;">
                            <i class="fas fa-crown" style="color: #7a2021; font-size: 16px;"></i>
                            <h3 class="item-name" style="color: #7a2021; font-size: 14px; margin: 0; font-weight: bold; font-family: 'Modesto Elementol', serif;">Legendary Action Rules</h3>
                        </header>
                        <div class="card-content" style="font-size: 12px; line-height: 1.4; color: #191813;">
                            <p style="margin: 0 0 6px 0;"><strong>${actor.name}</strong> can take legendary actions, choosing from the options available in its statblock. Only one legendary action option can be used at a time and only at the end of another creature's turn.</p>
                            <p style="margin: 0;">Spent legendary actions are fully regained at the start of <strong>${actor.name}</strong>'s turn.</p>
                        </div>
                    </div>
                `;

                await ChatMessage.create({
                    user: game.user.id,
                    speaker: ChatMessage.getSpeaker({ actor }),
                    content: cardContent
                });
            };
        }
    }

    static launch(actor, legendaryItems) {
        const dock = new LegendaryDock(actor, legendaryItems);
        dock.render(true);
    }
}

export function buildNpcPane(actor, container) {
    if (!actor || !container) return;

    // Prevent rendering inside standalone popout dialogs
    const isDock = container.closest('[data-raug-dock="true"]') ||
                   container.closest('.raug-dock-isolated') ||
                   container.closest('.raug-legendary-dock-window') ||
                   container.closest('.window-app.dialog') ||
                   container.closest('dialog');

    if (isDock) {
        const wrapper = container.closest('.raug-npc-utility-wrapper') || container.closest('.raug-npc-pane') || container;
        wrapper?.remove();
        return;
    }

    try {
        // 1. Fetch Vitals & Calculate Percentages using native JS
        const hp = actor.system?.attributes?.hp || { value: 0, max: 0, temp: 0 };
        const ac = actor.system?.attributes?.ac?.value ?? 10;
        const tempHpText = hp.temp ? `<span style="color:#71b6d1;">(+${hp.temp})</span>` : "";

        const maxHp = hp.max || 1;
        const rawPct = Math.round((hp.value / maxHp) * 100);
        const hpPct = Math.min(Math.max(rawPct, 0), 100);

        // 2. Inject Vitals Container with Background Health Bar into Header
        const wrapperParent = container.parentElement || container;
        const headerToggle = wrapperParent.querySelector(".raug-npc-outer-toggle") || 
                             wrapperParent.previousElementSibling ||
                             wrapperParent.querySelector("header");

        if (headerToggle) {
            let vitalsSpan = headerToggle.querySelector(".raug-header-vitals");
            if (!vitalsSpan) {
                vitalsSpan = document.createElement("span");
                vitalsSpan.className = "raug-header-vitals";
                
                // Position between Title and Expand Text
                const clickTextNode = Array.from(headerToggle.childNodes).find(n => n.textContent?.includes("Click to Expand"));
                if (clickTextNode) {
                    headerToggle.insertBefore(vitalsSpan, clickTextNode);
                } else {
                    headerToggle.appendChild(vitalsSpan);
                }
            }

            // Container styles act as the bar track; inner div is the green fill
            vitalsSpan.style.cssText = `
                position: relative;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                font-size: 11px;
                padding: 5px 8px;
                margin: 0 8px;
                background: rgba(0, 0, 0, 0.45);
                border: 1px solid #333;
                border-radius: 3px;
                overflow: hidden;
                flex-grow: 1;
                max-width: 200px;
                box-sizing: border-box;
            `;

            vitalsSpan.innerHTML = `
                <div class="raug-hp-bar-fill" style="
                    position: absolute;
                    top: 0;
                    left: 0;
                    bottom: 0;
                    width: ${hpPct}%;
                    background: linear-gradient(90deg, #00c524 0%, #2e7d32 100%);
                    opacity: 0.8;
                    transition: width 0.3s ease;
                    z-index: 1;
                "></div>
                <span style="position: relative; z-index: 2; color: #ffffff; font-weight: bold; text-shadow: 1px 1px 2px #000;">
                    <i class="fas fa-heart" style="color: #e27474; margin-right: 2px;"></i> ${hp.value}/${hp.max}${tempHpText}
                </span>
                <span style="position: relative; z-index: 2; color: #ffffff; font-weight: bold; text-shadow: 1px 1px 2px #000;">
                    <i class="fas fa-shield-alt" style="color: #6bb3e2; margin-right: 2px;"></i> AC ${ac}
                </span>
            `;
        }

        // 3. Process Actor Items
        const items = Array.from(actor.items || []);
        const multiItem = items.find(i => i.name.toLowerCase() === "multiattack");
        const legendary = items.filter(i => isLegendaryOrLair(i));

        const actions = items.filter(i => {
            if (legendary.includes(i) || i === multiItem) return false;
            if (i.type === "weapon" || i.type === "spell") return true;
            const actType = i.system?.activation?.type || "";
            return actType && actType !== "none" && actType !== "special";
        });

        const features = items.filter(i => !legendary.includes(i) && !actions.includes(i) && i !== multiItem);

        let topFlexRow = "";
        if (multiItem || legendary.length) {
            topFlexRow = `
                <div style="display: flex; gap: 4px; margin-bottom: 4px;">
                    ${multiItem ? `
                        <button type="button" class="raug-npc-item-btn" data-item-id="${multiItem.id}" style="
                            flex: 2; background: linear-gradient(90deg, #2b1d0c 0%, #1a1a1e 100%);
                            color: #c9b07a; border: 1px solid #c9b07a; font-size: 11px; font-weight: bold; padding: 4px 6px;
                            border-radius: 3px; cursor: pointer; text-align: left; display: flex; align-items: center; gap: 5px;
                            box-shadow: 0 0 3px rgba(201, 176, 122, 0.2); box-sizing: border-box; min-height: 25px; line-height: 1;
                        ">
                            <i class="fas fa-swords" style="font-size: 11px;"></i>
                            <span style="flex-grow: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Multiattack</span>
                            <span style="font-size: 8.5px; background: #c9b07a; color: #111; padding: 1px 4px; border-radius: 2px;">MAW</span>
                        </button>
                    ` : ""}

                    ${legendary.length ? `
                        <button type="button" class="raug-popout-legendary-btn" style="
                            flex: 1; background: linear-gradient(90deg, #3d1414 0%, #1a1a1e 100%);
                            color: #e27474; border: 1px solid #772222; font-size: 11px; font-weight: bold; padding: 4px 6px;
                            border-radius: 3px; cursor: pointer; display: flex; align-items: center; gap: 4px;
                            box-sizing: border-box; justify-content: center; min-height: 25px; white-space: nowrap; line-height: 1;
                        ">
                            <i class="fas fa-crown" style="font-size: 11px;"></i>
                            <span>Legendary (${legendary.length})</span>
                            <i class="fas fa-external-link-alt" style="font-size: 8.5px;"></i>
                        </button>
                    ` : ""}
                </div>
            `;
        }

        // 4. Render Expandable Action Content
        container.innerHTML = `
            <div class="raug-npc-pane-body" style="max-height: 200px; overflow-y: auto; padding-right: 2px; padding-top: 2px;">
                ${topFlexRow}

                ${actions.length ? `
                    <div style="font-size: 9px; font-weight: bold; color: #888; text-transform: uppercase; margin: 3px 0 2px 2px; border-bottom: 1px solid #333; padding-bottom: 1px;">
                        Actions
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px; margin-bottom: 4px;">
                        ${renderNpcItemList(actor, actions, !!multiItem)}
                    </div>
                ` : ""}

                ${features.length ? `
                    <div style="font-size: 9px; font-weight: bold; color: #888; text-transform: uppercase; margin: 3px 0 2px 2px; border-bottom: 1px solid #333; padding-bottom: 1px;">
                        Features & Passives
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px;">
                        ${renderNpcItemList(actor, features, false)}
                    </div>
                ` : ""}
            </div>
        `;

        container.querySelector(".raug-popout-legendary-btn")?.addEventListener("click", (e) => {
            e.preventDefault();
            LegendaryDock.launch(actor, legendary);
        });

        bindNpcItemListeners(actor, container);

    } catch (err) {
        console.error("RaugToolkit | Error rendering Unified NPC Pane:", err);
        container.innerHTML = `<div style="font-size:10px; color:#e27474; padding:4px;">Error building NPC tray. See console for details.</div>`;
    }
}

function clean5eDescriptionMarkup(text, actor) {
    if (!text) return "";
    let clean = text;
    const actorName = actor?.name || "the creature";
    clean = clean.replace(/\{monster\}/gi, actorName);
    clean = clean.replace(/\[\[lookup\s+@[^\]]+\]\]/gi, actorName);
    clean = clean.replace(/@UUID\[[^\]]+\]\{([^}]+)\}/gi, "$1");
    clean = clean.replace(/@UUID\[[^\]]+\]/gi, "");
    clean = clean.replace(/\[\[\/item\s+([^\]]+)\]\]/gi, "$1");
    clean = clean.replace(/\[\[\/?[^\]]+\]\]/gi, "");
    clean = clean.replace(/<[^>]*>?/gm, "").trim();
    return clean;
}

function renderNpcItemList(actor, itemList, hasMultiattack) {
    if (!itemList || !itemList.length) return "";

    return itemList.map(item => {
        const rawDesc = item.system?.description?.value || "";
        const itemNameLower = item.name.toLowerCase();

        const isComponentAttack = hasMultiattack && (item.type === "weapon" || ["rend", "bite", "claw", "slam", "sword", "dagger"].some(k => itemNameLower.includes(k)));

        const cleanDesc = clean5eDescriptionMarkup(rawDesc, actor);
        const descSnippet = cleanDesc ? `${cleanDesc.slice(0, 200)}${cleanDesc.length >= 200 ? "..." : ""}` : "No details.";

        const tooltipText = `
            <div style="text-align: left; max-width: 180px; font-size: 10px; line-height: 1.2;">
                <strong style="color: #c9b07a; font-size: 10.5px; display: block; border-bottom: 1px solid #555; padding-bottom: 2px; margin-bottom: 2px;">
                    ${item.name}
                </strong>
                <div style="color: #ddd;">${descSnippet}</div>
            </div>
        `.replace(/"/g, '&quot;');

        let opacityStyle = isComponentAttack ? "opacity: 0.45; filter: grayscale(40%);" : "";

        return `
            <button type="button" class="raug-npc-item-btn" data-item-id="${item.id}" data-tooltip="${tooltipText}" data-tooltip-direction="UP" style="
                background: #1a1a1e; color: #ddd; border: 1px solid #333; font-size: 9.5px; padding: 1px 2px;
                border-radius: 2px; cursor: pointer; text-align: left; display: flex; align-items: center; gap: 3px;
                width: 100%; box-sizing: border-box; min-height: 16px; ${opacityStyle}
            ">
                <img src="${item.img || 'icons/svg/item-bag.svg'}" style="width: 11px; height: 11px; border: none; border-radius: 2px; flex-shrink: 0;" />
                <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex-grow: 1;">${item.name}</span>
            </button>
        `;
    }).join("");
}

function bindNpcItemListeners(actor, container) {
    container.querySelectorAll(".raug-npc-item-btn").forEach(btn => {
        const item = actor.items.get(btn.dataset.itemId);
        if (!item) return;

        btn.onclick = async (e) => {
            e.preventDefault();

            if (item.name.toLowerCase() === "multiattack") {
                raugDebugLog("Launching Multiattack Wizard for NPC:", actor.name);
                MultiattackWizard.start(actor);
                return;
            }

            raugDebugLog("Using NPC item from tray:", item.name);
            if (typeof item.use === "function") {
                await item.use();
            } else if (typeof item.roll === "function") {
                await item.roll();
            } else {
                item.sheet?.render(true);
            }
        };

        btn.oncontextmenu = (e) => {
            e.preventDefault();
            item.sheet?.render(true);
        };
    });
}