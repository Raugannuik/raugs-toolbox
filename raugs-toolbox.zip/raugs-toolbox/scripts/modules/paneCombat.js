// scripts/modules/paneCombat.js
"use strict";

import { RAUG_CAT_BTN } from "./state.js";
import { getActiveFireShield, rollFireShieldRetaliation } from "./fireShield.js";

/**
 * Safe class resolver for TextEditor to prevent V13 deprecation warnings.
 */
function getTextEditorClass() {
    return foundry?.applications?.ux?.TextEditor?.implementation 
        || foundry?.applications?.ux?.TextEditor 
        || globalThis.TextEditor;
}

/**
 * Modern v13/dnd5e 5.x safe plain-text extractor for description tooltips.
 * Resolves @Embed, @UUID, and dynamic roll tags into clean text.
 */
async function clean5eDescriptionMarkup(text, actor) {
    if (!text) return "";

    let raw = text.replace(/\{monster\}/gi, actor?.name || "the character");
    const TextEditorClass = getTextEditorClass();

    let enriched = raw;
    if (TextEditorClass?.enrichHTML) {
        enriched = await TextEditorClass.enrichHTML(raw, {
            async: true,
            secrets: false,
            relativeTo: actor
        });
    }

    const parser = new DOMParser();
    const doc = parser.parseFromString(enriched, "text/html");
    const cleanText = doc.body.textContent || "";

    return cleanText.replace(/\s+/g, " ").trim();
}

export function buildCombatTestRow(actor, container) {
    if (!actor || !container) return;

    const shieldInfo = getActiveFireShield(actor);

    let fireShieldBtnHtml = "";
    let gridCols = "1fr";

    if (shieldInfo) {
        gridCols = "repeat(2, 1fr)";
        fireShieldBtnHtml = `
            <button type="button" id="raug-btn-fire-shield" style="background: ${shieldInfo.color}; color: #ffffff; border: 1px solid rgba(255,255,255,0.3); padding: 6px 10px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 11px; width: 100%; box-sizing: border-box;">
                <i class="fas ${shieldInfo.icon}"></i> ${shieldInfo.label} Retaliation
            </button>
        `;
    }

    container.innerHTML = `
        <strong style="color:#c9b07a; font-size:11px; display:block; margin-bottom:6px; font-weight:bold;">
            <i class="fas fa-swords"></i> Combat & Action Tools
        </strong>
        <div style="display:grid; grid-template-columns: ${gridCols}; gap:6px; padding:2px; margin-bottom: 8px;">
            <button type="button" id="raug-spellcasting-btn" style="${RAUG_CAT_BTN}"><i class="fas fa-hat-wizard"></i> Spells Selection</button>
            ${fireShieldBtnHtml}
        </div>
        
        <!-- Permanent Weapons / Physical Attacks Host -->
        <div id="raug-weapons-list-host"></div>
    `;

    if (shieldInfo) {
        container.querySelector("#raug-btn-fire-shield")?.addEventListener("click", (e) => {
            e.preventDefault();
            rollFireShieldRetaliation(actor, shieldInfo);
        });
    }

    container.querySelector("#raug-spellcasting-btn").onclick = () => {
        runRaugSpellcastingButtonMenu(actor);
    };

    const weaponsHost = container.querySelector("#raug-weapons-list-host");
    renderPhysicalEngineMenu(actor, weaponsHost);
}

export async function renderPhysicalEngineMenu(actor, hostElement) {
    if (!actor || !hostElement) return;

    const weapons = actor.items.filter(i => i.type === "weapon");

    if (!weapons.length) {
        hostElement.innerHTML = `<div style="font-size:11px; color:#888; text-align:center; padding:6px;">No weapons found on this sheet.</div>`;
        return;
    }

    const equippedWeapons = weapons.filter(w => w.system?.equipped);
    const unequippedWeapons = weapons.filter(w => !w.system?.equipped);

    let listHtml = `
        <div style="background:#111; border:1px solid #333; border-radius:4px; padding:6px; max-height:180px; overflow-y:auto;">
            <div style="font-size:10px; font-weight:bold; color:#c9b07a; margin-bottom:4px; border-bottom:1px solid #333; padding-bottom:2px; display:flex; justify-content:space-between; align-items:center;">
                <span><i class="fas fa-hand-fist"></i> Physical Attacks</span>
                <span style="font-size:8.5px; color:#777; font-weight:normal;">Left-Click: Attack | Right-Click: Toggle Equip</span>
            </div>
            <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(135px, 1fr)); gap:4px;">
    `;

    for (const item of equippedWeapons) {
        listHtml += await renderWeaponButton(actor, item, true);
    }

    for (const item of unequippedWeapons) {
        listHtml += await renderWeaponButton(actor, item, false);
    }

    listHtml += `</div></div>`;
    hostElement.innerHTML = listHtml;

    hostElement.querySelectorAll(".raug-physical-item-btn").forEach(btn => {
        const itemId = btn.dataset.itemId;
        const item = actor.items.get(itemId);
        if (!item) return;

        btn.addEventListener("mouseenter", () => {
            const htmlContent = btn.dataset.tooltipHtml;
            if (htmlContent && game.tooltip) {
                game.tooltip.activate(btn, { text: htmlContent, direction: "UP" });
            }
        });

        btn.addEventListener("mouseleave", () => {
            if (game.tooltip) game.tooltip.deactivate();
        });

        btn.onclick = async (e) => {
            e.preventDefault();
            if (game.tooltip) game.tooltip.deactivate();

            if (item.system?.activities && item.system.activities.size > 0) {
                const attackActivity = Array.from(item.system.activities.values()).find(a => a.type === "attack") 
                                     || Array.from(item.system.activities.values())[0];
                if (attackActivity && typeof attackActivity.use === "function") {
                    return await attackActivity.use({}, { event: e });
                }
            }

            if (typeof item.use === "function") {
                return await item.use({ legacy: false }, { event: e });
            }

            if (typeof item.rollAttack === "function") {
                return await item.rollAttack({ event: e });
            }

            item.sheet?.render(true);
        };

        btn.oncontextmenu = async (e) => {
            e.preventDefault();
            if (game.tooltip) game.tooltip.deactivate();

            const currentEquipped = !!item.system?.equipped;
            const newEquippedState = !currentEquipped;

            await item.update({ "system.equipped": newEquippedState });
            await postEquipChatMessage(actor, item, newEquippedState);

            await renderPhysicalEngineMenu(actor, hostElement);
        };
    });
}

async function renderWeaponButton(actor, item, isEquipped) {
    const bgStyle = isEquipped ? "#222" : "#141416";
    const borderStyle = isEquipped ? "1px solid #555" : "1px dashed #333";
    const opacityStyle = isEquipped ? "1.0" : "0.55";
    const statusTag = isEquipped ? "" : " <span style='font-size:8px; color:#888;'>(Unequipped)</span>";

    const rawDesc = item.system?.description?.value || "";
    const cleanDesc = await clean5eDescriptionMarkup(rawDesc, actor);
    const descSnippet = cleanDesc ? `${cleanDesc.slice(0, 180)}${cleanDesc.length >= 180 ? "..." : ""}` : "No description available.";

    const tooltipHtml = `
        <div style="text-align: left; max-width: 240px; font-size: 11px; line-height: 1.3;">
            <strong style="color: #c9b07a; font-size: 12px; display: block; border-bottom: 1px solid #555; padding-bottom: 2px; margin-bottom: 4px;">
                ${item.name} (${isEquipped ? 'Equipped' : 'Unequipped'})
            </strong>
            <div style="color: #ddd;">
                ${descSnippet}
            </div>
            <div style="font-size: 9px; color: #888; margin-top: 6px; border-top: 1px dashed #444; padding-top: 2px;">
                <i class="fas fa-mouse-pointer"></i> Left-Click: Attack | Right-Click: Toggle Equip
            </div>
        </div>
    `.replace(/"/g, '&quot;');

    const plainTitle = `${item.name} (${isEquipped ? 'Equipped' : 'Unequipped'})\n${descSnippet}`;

    return `
        <button type="button" class="raug-physical-item-btn" data-item-id="${item.id}" data-tooltip-html="${tooltipHtml}" title="${plainTitle.replace(/"/g, '&quot;')}" style="
            background: ${bgStyle}; 
            color: ${isEquipped ? '#e0e0e0' : '#888888'}; 
            border: ${borderStyle}; 
            opacity: ${opacityStyle};
            font-size: 10px; 
            padding: 4px 6px; 
            border-radius: 3px; 
            cursor: pointer; 
            text-align: left; 
            text-overflow: ellipsis; 
            overflow: hidden; 
            white-space: nowrap;
            display: flex;
            align-items: center;
            transition: all 0.15s ease;
        " onmouseover="this.style.opacity='1.0';" onmouseout="this.style.opacity='${opacityStyle}';">
            <img src="${item.img}" style="width:14px; height:14px; vertical-align:middle; margin-right:5px; border:none; flex-shrink:0; border-radius:2px;"/>
            <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${item.name}${statusTag}</span>
        </button>
    `;
}

/**
 * Handles posting equip/unequip chat notifications cleanly glued inside the inner box.
 * Dynamic bookkeeping for active attunement slots (e.g., Attuned 2/3).
 */
async function postEquipChatMessage(actor, item, isEquipping) {
    const statusText = isEquipping ? "equips" : "unequips";
    
    // Determine item attunement state
    const attunementVal = item.system?.attunement;
    const isAttuned = item.system?.attuned || attunementVal === "attuned" || attunementVal === 2;
    const requiresAttunement = attunementVal === "required" || attunementVal === 1 || isAttuned;

    let attunementText = "";
    if (requiresAttunement) {
        // Fetch actor attunement counts from dnd5e actor schema
        const attunementData = actor.system?.attributes?.attunement;
        const currentAttuned = attunementData?.value ?? actor.items.filter(i => i.system?.attuned || i.system?.attunement === "attuned" || i.system?.attunement === 2).length;
        const maxAttuned = attunementData?.max ?? 3;

        const countRatio = `${currentAttuned}/${maxAttuned}`;

        if (isAttuned) {
            attunementText = ` <span style='color:#1b6b33; font-size:10px; font-weight:600;'>(Attuned ${countRatio})</span>`;
        } else {
            attunementText = ` <span style='color:#555555; font-size:10px; font-weight:600;'>(Unattuned ${countRatio})</span>`;
        }
    }

    const itemLink = `@UUID[${item.uuid}]{${item.name}}`;
    const entryLine = `<div style="font-size:12px; line-height:1.45; color: #191813;">• <strong>${actor.name}</strong> ${statusText} ${itemLink}${attunementText}.</div>`;

    const lastMsg = game.messages.contents.slice(-1)[0];
    const isSameActor = lastMsg?.speaker?.actor === actor.id;
    const isEquipCard = lastMsg?.flags?.raug?.isEquipCard;
    const TextEditorClass = getTextEditorClass();

    if (lastMsg && isSameActor && isEquipCard) {
        let content = lastMsg.content;
        const lastDivIndex = content.lastIndexOf("</div>");
        let newContent = "";
        
        if (lastDivIndex !== -1) {
            newContent = content.slice(0, lastDivIndex) + entryLine + content.slice(lastDivIndex);
        } else {
            newContent = content + entryLine;
        }

        const enrichedContent = TextEditorClass?.enrichHTML 
            ? await TextEditorClass.enrichHTML(newContent, { secrets: false, async: true, relativeTo: actor })
            : newContent;

        await lastMsg.update({ content: enrichedContent });
    } else {
        const fullCardHtml = `
            <div style="background: rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.15); border-radius: 4px; padding: 6px 8px; color: #191813;">
                <div style="font-size:11px; font-weight:bold; color:#7a0000; border-bottom:1px solid rgba(0,0,0,0.15); padding-bottom:3px; margin-bottom:4px;">
                    <i class="fas fa-shield-halved"></i> Equipment Change
                </div>
                ${entryLine}
            </div>
        `;

        const enrichedContent = TextEditorClass?.enrichHTML 
            ? await TextEditorClass.enrichHTML(fullCardHtml, { secrets: false, async: true, relativeTo: actor })
            : fullCardHtml;

        await ChatMessage.create({
            speaker: ChatMessage.getSpeaker({ actor }),
            content: enrichedContent,
            flags: { raug: { isEquipCard: true } }
        });
    }
}

export async function runRaugSpellcastingButtonMenu(actor) {
    if (!actor) return;

    const spells = actor.items.filter(i => i.type === "spell");

    if (!spells.length) {
        return ui.notifications.info(`${actor.name} has no spells prepared or known.`);
    }

    const spellsByLevel = {};
    spells.forEach(spell => {
        const lvl = spell.system?.level ?? 0;
        if (!spellsByLevel[lvl]) spellsByLevel[lvl] = [];
        spellsByLevel[lvl].push(spell);
    });

    let dialogContent = `
        <div style="
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; 
            max-height: 420px; 
            overflow-y: auto; 
            padding: 8px 12px;
            color: #191813;
        ">
    `;

    Object.keys(spellsByLevel).sort((a,b) => a - b).forEach(lvlStr => {
        const lvl = Number(lvlStr);
        const label = lvl === 0 ? "Cantrips" : `Level ${lvl}`;
        
        let slotsText = "";
        if (lvl > 0) {
            const slots = actor.system?.spells?.[`spell${lvl}`];
            if (slots && slots.max > 0) {
                const available = slots.value ?? 0;
                const slotColor = available > 0 ? "#1b6b33" : "#a32a2a";
                slotsText = ` <span style="color: ${slotColor}; font-size: 11px; font-weight: 600;">(${available}/${slots.max} slots)</span>`;
            }
        }

        dialogContent += `
            <div style="
                font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
                font-size: 12px; 
                font-weight: 700; 
                color: #2b2b2b; 
                margin-top: 12px; 
                margin-bottom: 6px; 
                border-bottom: 1px solid #7a7971; 
                padding-bottom: 3px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                display: flex;
                align-items: center;
                gap: 6px;
            ">
                <span>${label}</span>
                ${slotsText}
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 6px; margin-bottom: 10px;">
        `;

        spellsByLevel[lvl].forEach(spell => {
            dialogContent += `
                <button type="button" class="raug-dialog-spell-btn" data-item-id="${spell.id}" style="
                    background: linear-gradient(to bottom, #f7f3e8 0%, #eadabe 100%);
                    color: #191813;
                    border: 1px solid #b5a48b;
                    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.4), 0 1px 2px rgba(0,0,0,0.15);
                    font-size: 11px;
                    font-weight: 600;
                    padding: 5px 8px;
                    border-radius: 3px;
                    cursor: pointer;
                    text-align: left;
                    display: flex;
                    align-items: center;
                    transition: all 0.15s ease-in-out;
                ">
                    <img src="${spell.img}" style="width: 16px; height: 16px; margin-right: 6px; border: 1px solid #999; border-radius: 2px; flex-shrink: 0; object-fit: cover;"/>
                    <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${spell.name}</span>
                </button>
            `;
        });

        dialogContent += `</div>`;
    });

    dialogContent += `</div>`;

    const setupListeners = (root, closeFn) => {
        root.querySelectorAll(".raug-dialog-spell-btn").forEach(btn => {
            btn.addEventListener("mouseenter", () => {
                btn.style.background = "linear-gradient(to bottom, #fffdf8 0%, #f3e5c8 100%)";
                btn.style.borderColor = "#7a0000";
                btn.style.color = "#7a0000";
            });
            btn.addEventListener("mouseleave", () => {
                btn.style.background = "linear-gradient(to bottom, #f7f3e8 0%, #eadabe 100%)";
                btn.style.borderColor = "#b5a48b";
                btn.style.color = "#191813";
            });

            btn.onclick = async () => {
                const itemId = btn.dataset.itemId;
                const spell = actor.items.get(itemId);
                
                if (closeFn) closeFn();

                if (!spell) return;

                if (typeof spell.use === "function") {
                    await spell.use();
                } else {
                    ui.notifications.warn(`Cannot cast spell: ${spell.name}`);
                }
            };
        });
    };

    if (foundry.applications?.api?.DialogV2) {
        return foundry.applications.api.DialogV2.prompt({
            window: { title: `Spellbook: ${actor.name}` },
            content: dialogContent,
            ok: { label: "Close", icon: "fas fa-times", callback: () => {} },
            render: (event) => {
                const root = event.target.element;
                setupListeners(root, () => event.target.close());
            }
        });
    }

    const d = new Dialog({
        title: `Spellbook: ${actor.name}`,
        content: dialogContent,
        buttons: {
            close: {
                label: "Close",
                icon: '<i class="fas fa-times"></i>'
            }
        },
        default: "close",
        render: (html) => {
            const root = html instanceof HTMLElement ? html : html[0];
            setupListeners(root, () => d.close());
        }
    }, { 
        width: 500,
        classes: ["dnd5e2", "sheet", "raug-spell-popup"]
    });

    d.render(true);
}