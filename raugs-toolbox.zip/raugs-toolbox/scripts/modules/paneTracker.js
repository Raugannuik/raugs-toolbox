"use strict";

import { raugSourceLabel, raugDamageOnSave, RAUG_MODULE_ID } from "./state.js";

const MODULE_SCOPE = RAUG_MODULE_ID || "raugs-toolbox";
const SETTING_SAVED_CONTEXTS = "globalCombatContexts";
const SETTING_SESSION_ANCHOR = "globalSessionAnchor";

export async function loadGlobalContexts() {
    const saved = game.settings.get(MODULE_SCOPE, SETTING_SAVED_CONTEXTS) || [];
    window.RAUG_ACTIVE_CONTEXTS = saved;
    return window.RAUG_ACTIVE_CONTEXTS;
}

export async function saveGlobalContext(newContext) {
    if (!window.RAUG_ACTIVE_CONTEXTS) window.RAUG_ACTIVE_CONTEXTS = [];
    
    if (newContext) {
        window.RAUG_ACTIVE_CONTEXTS.push(newContext);
    }

    if (window.RAUG_ACTIVE_CONTEXTS.length > 250) {
        window.RAUG_ACTIVE_CONTEXTS.shift();
    }

    if (game.user.isGM) {
        await game.settings.set(MODULE_SCOPE, SETTING_SAVED_CONTEXTS, window.RAUG_ACTIVE_CONTEXTS);
    }
}

export async function getSessionAnchor() {
    return game.settings.get(MODULE_SCOPE, SETTING_SESSION_ANCHOR) || 0;
}

export async function setSessionAnchor(timestamp = Date.now()) {
    if (!timestamp) {
        window.RAUG_ACTIVE_CONTEXTS = [];
        if (game.user.isGM) {
            await game.settings.set(MODULE_SCOPE, SETTING_SAVED_CONTEXTS, []);
            await game.settings.set(MODULE_SCOPE, SETTING_SESSION_ANCHOR, 0);
        }
    } else if (game.user.isGM) {
        await game.settings.set(MODULE_SCOPE, SETTING_SESSION_ANCHOR, timestamp);
    }
}

export async function buildCombatBreakdownPane(actor, container, shouldCompile = false, shouldExport = false) {
    if (!container) return;

    await loadGlobalContexts();

    const currentAnchor = await getSessionAnchor();
    const anchorStatusText = currentAnchor ? `Global Session Running` : `No Active Session (Unanchored)`;
    const statusColor = currentAnchor ? `#2e7d32` : `#c62828`;
    const bStyle = `width:100%; text-align:left; padding:4px 8px; line-height:1.25; font-weight:bold; font-size:10px; background:#262626; color:#d6d6d6; border:1px solid #444; border-radius:4px; cursor:pointer; margin-bottom:4px; display:block;`;

    container.innerHTML = `
        <div style="font-family:sans-serif; font-size:12px; display:flex; flex-direction:column; gap:2px; padding:2px;">
            <div id="raug-anchor-status" style="text-align:center; padding:3px; font-weight:bold; color:${statusColor}; font-size:10px; background:rgba(0,0,0,0.15); border-radius:4px; margin-bottom:6px; border:1px solid #333;">${anchorStatusText}</div>
            <button type="button" id="raug-metrics-set" style="${bStyle}"><i class="fas fa-flag" style="color:#c9b07a;"></i> Start Global Session</button>
            <button type="button" id="raug-metrics-compile" style="${bStyle}"><i class="fas fa-chart-bar" style="color:#c9b07a;"></i> Compile Encounter Report</button>
            <button type="button" id="raug-metrics-export" style="${bStyle}"><i class="fas fa-file-download" style="color:#64b5f6;"></i> Export Encounter Data</button>
            <button type="button" id="raug-metrics-clear" style="${bStyle}"><i class="fas fa-times" style="color:#b71c1c;"></i> Reset / Clear Global Anchor</button>
        </div>
    `;

    container.querySelector("#raug-metrics-set").onclick = async () => {
        await setSessionAnchor(Date.now());
        ui.notifications.info(`Global encounter tracking started!`);
        buildCombatBreakdownPane(actor, container);
    };

    container.querySelector("#raug-metrics-compile").onclick = () => executeRefactoredMetricsCompilation(actor, false, container);
    container.querySelector("#raug-metrics-export").onclick = () => executeRefactoredMetricsCompilation(actor, true, container);
    
    container.querySelector("#raug-metrics-clear").onclick = async () => {
        await setSessionAnchor(null);
        ui.notifications.warn(`Global combat log reset.`);
        buildCombatBreakdownPane(actor, container);
    };

    if (!shouldCompile) return;

    const anchorTime = await getSessionAnchor();
    const activeContexts = window.RAUG_ACTIVE_CONTEXTS || [];
    const sessionContexts = activeContexts.filter(c => c.timestamp >= anchorTime);

    if (!sessionContexts.length) {
        const emptyMsg = `<p style="padding:12px; color:#f0f0f0; font-family:sans-serif; font-size:12px; margin:0;">No encounter metrics recorded during this session window.</p>`;
        
        if (foundry.applications?.api?.DialogV2) {
            foundry.applications.api.DialogV2.prompt({
                window: { title: "Encounter Combat Report" },
                content: emptyMsg,
                ok: { label: "Close" }
            });
        } else {
            new Dialog({ title: "Encounter Combat Report", content: emptyMsg, buttons: { close: { label: "Close" } } }).render(true);
        }
        return;
    }

    const metrics = {};
    let grandTotalDamage = 0;
    let grandTotalApplied = 0;
    const globalDamageTypes = {};

    const initSource = (label) => {
        if (!metrics[label]) {
            metrics[label] = { 
                damage: 0, 
                appliedDamage: 0, 
                attacks: 0, 
                hits: 0, 
                misses: 0, 
                crits: 0, 
                saves: 0, 
                fails: 0, 
                damageTypes: {} 
            };
        }
        return metrics[label];
    };

    const recordType = (sourceMetrics, rawTypeName, amount) => {
        if (!rawTypeName || amount <= 0) return;
        
        // Clean string (e.g. "Fire: 25" -> "Fire")
        const cleanName = String(rawTypeName).split(":")[0].trim();
        const formattedType = cleanName.charAt(0).toUpperCase() + cleanName.slice(1).toLowerCase();
        
        sourceMetrics.damageTypes[formattedType] = (sourceMetrics.damageTypes[formattedType] || 0) + amount;
        globalDamageTypes[formattedType] = (globalDamageTypes[formattedType] || 0) + amount;
    };

    const processDamageRoll = (parentLabel, rollObj, isCrit = false) => {
        const total = Number(rollObj.total || rollObj.damage || 0);
        if (total <= 0) return;

        const data = initSource(parentLabel);
        data.damage += total;
        if (isCrit) data.crits++;
        grandTotalDamage += total;

        let recordedAny = false;

        let details = rollObj.damageDetails;
        if (!Array.isArray(details) || !details.length) {
            if (Array.isArray(rollObj.damageRolls) && rollObj.damageRolls.length > 0) {
                details = rollObj.damageRolls.flatMap(r => r.damageDetails || []).filter(Boolean);
            }
        }

        if (Array.isArray(details) && details.length > 0) {
            details.forEach(d => {
                const amt = Number(d.total || 0);
                if (amt > 0 && d.type) {
                    recordType(data, d.type, amt);
                    recordedAny = true;
                }
            });
        }

        if (!recordedAny && Array.isArray(rollObj.damageRolls) && rollObj.damageRolls.length > 0) {
            rollObj.damageRolls.forEach(r => {
                const subType = r.damageType || r.type;
                const subTotal = Number(r.total || 0);
                if (subType && subTotal > 0) {
                    recordType(data, subType, subTotal);
                    recordedAny = true;
                }
            });
        }

        if (!recordedAny) {
            const fallbackType = rollObj.damageType || rollObj.type || "untyped";
            recordType(data, fallbackType, total);
        }
    };

    // Pre-pass: Map spell timestamps to filter out secondary damage_applied events
    const spellTimestamps = sessionContexts
        .filter(c => c.type === "spell")
        .map(c => c.timestamp);

    sessionContexts.forEach(ctx => {
        const baseLabel = raugSourceLabel(ctx);

        // Filter out secondary manual/direct HP application events generated right after a spell roll
        if (ctx.type === "damage_applied" || ctx.type === "damage_only") {
            const isSecondarySpellEcho = spellTimestamps.some(t => Math.abs(ctx.timestamp - t) < 180000); // 3-min window
            if (isSecondarySpellEcho && (ctx.sourceName === "Manual / Direct HP" || !ctx.originUuid)) {
                return;
            }
        }

        const data = initSource(baseLabel);

        if (ctx.type === "attack") {
            data.attacks++;
            if (ctx.appliedDamage !== undefined) {
                data.appliedDamage += Number(ctx.appliedDamage);
                grandTotalApplied += Number(ctx.appliedDamage);
            }
            if (ctx.resolved && ctx.damageRolls && ctx.damageRolls.length > 0) {
                data.hits++;
                ctx.damageRolls.forEach(d => {
                    processDamageRoll(baseLabel, d, d.isCrit || ctx.isCrit);
                });
            } else {
                data.misses++;
            }
        } else if (ctx.type === "damage_only" || ctx.type === "damage_applied") {
            if (ctx.appliedDamage !== undefined) {
                data.appliedDamage += Number(ctx.appliedDamage);
                grandTotalApplied += Number(ctx.appliedDamage);
            }
            processDamageRoll(baseLabel, ctx, ctx.isCrit);
        } else if (ctx.type === "spell") {
            const saves = ctx.saves || [];
            saves.forEach(p => p.passed ? data.saves++ : data.fails++);
            
            const rolls = ctx.damageRolls || [];
            const onSave = ctx.onSave || "half";

            rolls.forEach(d => {
                const baseRollTotal = Number(d.total || d.damage || 0);

                // 1. Calculate sum across all target saves (e.g., 25 failed + 12 passed = 37)
                let multiTargetTotal = 0;
                if (saves.length > 0) {
                    multiTargetTotal = saves.reduce((sum, targetSave) => {
                        return sum + raugDamageOnSave(baseRollTotal, targetSave.passed, onSave);
                    }, 0);
                    multiTargetTotal = Math.round(multiTargetTotal);
                } else {
                    multiTargetTotal = baseRollTotal;
                }

                // 2. ROLLED DAMAGE: Multi-target output (37)
                data.damage += multiTargetTotal;
                grandTotalDamage += multiTargetTotal;
                if (d.isCrit || ctx.isCrit) data.crits++;

                // 3. APPLIED HP: Default to multi-target sum (37)
                data.appliedDamage += multiTargetTotal;
                grandTotalApplied += multiTargetTotal;

                // 4. DAMAGE TYPES: Record damage type using sanitized name & output total
                let rawType = d.damageType || d.type;
                if (!rawType && Array.isArray(d.damageDetails) && d.damageDetails.length > 0) {
                    rawType = d.damageDetails[0].type;
                }
                
                let typeName = rawType ? String(rawType).split(":")[0].trim() : "fire";
                if (!typeName) typeName = "fire";

                recordType(data, typeName, multiTargetTotal);
            });
        }
    });

    if (shouldExport) {
        let txt = "Source (Action) -> Target\tRolled Damage\tApplied HP Damage\tDamage Types\tAttacks\tHits\tMisses\tCrits\tSaves Passed\tSaves Failed\r\n";
        for (const [src, d] of Object.entries(metrics)) {
            const typeStr = Object.entries(d.damageTypes).map(([t, amt]) => `${t}: ${amt}`).join(", ") || "N/A";
            txt += `${src}\t${d.damage}\t${d.appliedDamage}\t${typeStr}\t${d.attacks}\t${d.hits}\t${d.misses}\t${d.crits}\t${d.saves}\t${d.fails}\r\n`;
        }
        txt += `\r\nGRAND ENCOUNTER TOTALS\tRolled: ${grandTotalDamage}\tApplied: ${grandTotalApplied}`;
        const blob = new Blob([txt], { type: "text/plain;charset=utf-8;" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.setAttribute("download", `encounter_combat_report.txt`);
        link.click();
    } else {
        let html = `<div style="font-family:sans-serif; font-size:12px; max-height:360px; overflow-y:auto; color:#e0e0e0; padding:6px;">`;
        
        for (const [src, d] of Object.entries(metrics)) {
            if (d.damage === 0 && d.appliedDamage === 0 && d.attacks === 0 && d.saves === 0 && d.fails === 0) continue;

            const typesFormatted = Object.entries(d.damageTypes)
                .map(([type, amt]) => `<span style="color:#81d4fa;">${amt} ${type}</span>`)
                .join(", ");

            html += `<div style="border-left:3px solid #c9b07a; padding-left:8px; margin-bottom:8px; background:rgba(255,255,255,0.04); padding-top:4px; padding-bottom:4px; border-radius:0 4px 4px 0;">`;
            html += `<strong style="color:#ffffff; font-size:13px;">${src}</strong><br>`;
            html += `<span style="color:#cccccc;">Rolled: <strong style="color:#64b5f6;">${d.damage}</strong> | Applied HP: <strong style="color:#ef5350;">${d.appliedDamage}</strong> | Crits: <strong style="color:#ffb74d;">${d.crits}</strong></span>`;
            if (typesFormatted) html += `<br><span style="font-size:11px; color:#b0bec5;">Types: ${typesFormatted}</span>`;
            if (d.attacks > 0) html += `<br><span style="color:#aaa;">Attacks: ${d.attacks} (Hits: ${d.hits} | Misses: ${d.misses})</span>`;
            if (d.saves || d.fails) html += `<br><span style="color:#aaa;">Saves: ${d.saves} passed / ${d.fails} failed</span>`;
            html += `</div>`;
        }
        
        const globalTypesFormatted = Object.entries(globalDamageTypes)
            .map(([type, amt]) => `<strong style="color:#81d4fa;">${amt}</strong> ${type}`)
            .join(" | ");

        html += `<hr style="border-color:#444444; margin:8px 0;">`;
        if (globalTypesFormatted) {
            html += `<div style="font-size:11px; color:#b0bec5; margin-bottom:4px; text-align:right;">Types Total: ${globalTypesFormatted}</div>`;
        }
        html += `<div style="text-align:right; font-size:13px;"><strong style="color:#c9b07a;">Rolled Total:</strong> <strong style="color:#81c784; font-size:14px;">${grandTotalDamage}</strong> | <strong style="color:#c9b07a;">Applied HP Total:</strong> <strong style="color:#ef5350; font-size:14px;">${grandTotalApplied}</strong></div>`;
        html += `</div>`;
        
        if (foundry.applications?.api?.DialogV2) {
            foundry.applications.api.DialogV2.prompt({
                window: { title: `Global Encounter Report` },
                content: html,
                ok: { label: "Close" }
            });
        } else {
            new Dialog({ title: `Global Encounter Report`, content: html, buttons: { close: { label: "Close" } } }).render(true);
        }
    }
}

export async function executeRefactoredMetricsCompilation(actor, shouldExport, container) {
    const pane = container || document.querySelector(`#raug-master-toolbox-panel #raug-pane-utility`);
    if (!pane) return;
    await buildCombatBreakdownPane(actor, pane, true, shouldExport);
}

Hooks.on("canvasReady", async () => {
    await loadGlobalContexts();
});