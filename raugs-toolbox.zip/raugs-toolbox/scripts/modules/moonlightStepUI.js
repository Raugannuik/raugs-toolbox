// scripts/modules/moonlightStepUI.js
"use strict";

export async function handleMoonlightStepUseViaWrapper(wrapped, item, args) {
    const actor = item.actor;
    if (!actor) return await wrapped.apply(item, args);

    const chatMessageIdBefore = game.messages.contents.at(-1)?.id;

    // 1. Hook onto the resulting chat card creation
    const hookId = Hooks.on("renderChatMessage", async (message, html) => {
        // Ignore old messages or messages from other actors
        if (message.id === chatMessageIdBefore) return;
        if (message.speaker?.actor !== actor.id && message.actor?.id !== actor.id) return;

        // Ensure we only process this card once
        if (message.flags?.raugToolkit?.moonlightStepProcessed) return;

        // Unhook immediately to prevent double execution
        Hooks.off("renderChatMessage", hookId);

        // --- 2. USES / CHARGES ACCOUNTING ---
        const uses = item.system?.uses ?? {};
        const maxUses = Number(uses.max ?? 0);
        const spent = Number(uses.spent ?? 0);
        const remaining = Math.max(0, maxUses - spent);

        // --- 3. SPELL SLOT DETECTION ---
        const slotLvlUsed = message.flags?.dnd5e?.use?.spellSlot;
        const wasSpellSlot = !!slotLvlUsed;

        const noteText = wasSpellSlot
            ? `Expended a Level ${slotLvlUsed} Spell Slot.`
            : "Expended a free class charge.";

        // --- 4. FOOTER ACCOUNTING HTML ---
        let footerAccountingHtml = "";

        if (!wasSpellSlot) {
            const color = remaining === 0 ? "#b71c1c" : "#e65100";
            footerAccountingHtml = `
                <div style="margin-top:6px;border-top:1px solid rgba(0,0,0,0.05);padding-top:4px;font-weight:bold;color:${color};text-align:center;">
                    📊 ${remaining} / ${maxUses} Free Class Charges Remaining
                </div>`;
        } else {
            const slotData = actor.system?.spells?.[`spell${slotLvlUsed}`] ?? {};
            const remainingSlots = slotData.value ?? 0;
            const totalSlots = slotData.max ?? 0;
            const color = remainingSlots === 0 ? "#b71c1c" : "#e65100";

            footerAccountingHtml = `
                <div style="margin-top:6px;border-top:1px solid rgba(0,0,0,0.05);padding-top:4px;font-weight:bold;color:${color};text-align:center;">
                    🔮 ${remainingSlots} / ${totalSlots} Level ${slotLvlUsed} Spell Slots Remaining
                </div>`;
        }

        // --- 5. LEVEL 14 PASSENGER UPGRADE (LUNAR FORM TOOLTIP) ---
        const druidClass = actor.itemTypes?.class?.find(c => c.name.toLowerCase().includes("druid"));
        const druidLevel = druidClass ? (druidClass.system?.levels || 0) : (actor.system?.details?.level ?? 1);
        
        let passengerText = "";
        if (druidLevel >= 14) {
            const lunarFormItem = actor.items.find(i => i.name.toLowerCase().includes("lunar form"));
            const lunarFormLink = lunarFormItem 
                ? `@UUID[Actor.${actor.id}.Item.${lunarFormItem.id}]{Lunar Form}`
                : "Lunar Form";

            passengerText = `
                <div style="background:rgba(122,92,41,0.05);border:1px dashed #7a5c29;padding:4px;margin-top:5px;border-radius:4px;font-size:11px;">
                    <strong>🌙 ${lunarFormLink} Upgrade:</strong> You can teleport a willing creature within 5 feet along with you.
                </div>`;
        }

        // --- 6. FINAL BOOKKEEPING BLOCK ---
        const finalBlock = `
            <div class="glued-bookkeeping-footer"
                 style="background:rgba(201,176,122,0.04);border-left:3px solid #c9b07a;padding:4px;margin-top:6px;font-size:12px;font-family:sans-serif;color:#333;width:100%;box-sizing:border-box;">
                <strong>Resource Accounting:</strong> ${noteText}<br>
                <strong>Feature Source:</strong> @UUID[Actor.${actor.id}.Item.${item.id}]{Moonlight Step}<br>
                <strong>Range / Target:</strong> 30 Feet Teleport<br>
                <strong>Tactical Buff:</strong> Advantage on your next attack roll before the end of this turn.
                ${passengerText}
                ${footerAccountingHtml}
            </div>
        `;

        // --- 7. TEXT ENRICHMENT & DOM INJECTION ---
        const textEditor = foundry.applications?.ux?.TextEditor?.implementation || TextEditor;
        const enrichedContent = await textEditor.enrichHTML(finalBlock, { async: true });

        const contentElem = html[0]?.querySelector(".message-content") ||
                            html[0]?.querySelector(".card-content") ||
                            html[0];

        if (contentElem && !contentElem.querySelector(".glued-bookkeeping-footer")) {
            const wrapper = document.createElement("div");
            wrapper.innerHTML = enrichedContent;
            contentElem.appendChild(wrapper.firstElementChild);
        }

        // --- 8. PERSIST TO DATABASE CHAT MESSAGE ---
        await message.update(
            { 
                content: message.content + enrichedContent,
                "flags.raugToolkit.moonlightStepProcessed": true
            },
            { diff: false, render: true }
        );
    });

    // Clean up hook if no message was created after 4 seconds
    setTimeout(() => Hooks.off("renderChatMessage", hookId), 4000);

    // Execute standard item usage
    return await wrapped.apply(item, args);
}