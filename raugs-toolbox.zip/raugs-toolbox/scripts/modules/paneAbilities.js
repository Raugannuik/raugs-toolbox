// scripts/modules/paneAbilities.js
"use strict";

import { raugDebugLog } from "./state.js";

function injectAbilitiesMinimizerStyles() {
    if (document.getElementById("raug-abilities-minimizer-styles")) return;

    const style = document.createElement("style");
    style.id = "raug-abilities-minimizer-styles";
    style.innerHTML = `
        /* Retain columns and enable horizontal scroll if width constrained */
        .window-app.actor.minimized .raug-abilities-container,
        .application.actor.minimized .raug-abilities-container {
            display: grid !important;
            grid-template-columns: repeat(3, minmax(130px, 1fr)) !important;
            overflow-x: auto !important;
            overflow-y: auto !important;
            gap: 8px !important;
            padding-bottom: 4px !important;
        }

        /* Prevent inner button grids from crushing buttons together */
        .window-app.actor.minimized .raug-abilities-container div[style*="grid-template-columns"],
        .application.actor.minimized .raug-abilities-container div[style*="grid-template-columns"] {
            grid-template-columns: repeat(auto-fill, minmax(110px, 1fr)) !important;
            gap: 4px !important;
        }

        /* Enforce hard minimum sizing on individual button items */
        .window-app.actor.minimized .raug-static-ability-btn,
        .application.actor.minimized .raug-static-ability-btn {
            min-width: 110px !important;
            box-sizing: border-box !important;
        }
    `;
    document.head.appendChild(style);
}

function clean5eDescriptionMarkup(text, actor) {
    if (!text) return "";

    let clean = text;

    // 1. Resolve {monster} or [[lookup @name]] tokens
    const actorName = actor?.name || "the character";
    clean = clean.replace(/\{monster\}/gi, actorName);
    clean = clean.replace(/\[\[lookup\s+@[^\]]+\]\]/gi, actorName);

    // 2. Resolve @UUID[...]{Label} -> "Label"
    clean = clean.replace(/@UUID\[[^\]]+\]\{([^}]+)\}/gi, "$1");
    clean = clean.replace(/@UUID\[[^\]]+\]/gi, "");

    // 3. Resolve [[/item Item Name]] -> "Item Name"
    clean = clean.replace(/\[\[\/item\s+([^\]]+)\]\]/gi, "$1");

    // 4. Clean inline roll brackets or commands [[...]]
    clean = clean.replace(/\[\[\/?[^\]]+\]\]/gi, "");

    // 5. Strip standard HTML tags
    return clean.replace(/<[^>]*>?/gm, "").trim();
}

/**
 * Helper function to check if an item is an Active ability across dnd5e versions.
 */
function isItemActive(item) {
    const actType = item.system?.activation?.type;
    if (actType && actType !== "none" && actType !== "") return true;

    const activities = item.system?.activities;
    if (activities) {
        const activityList = activities instanceof Map ? Array.from(activities.values()) : Object.values(activities);
        if (activityList.some(act => act.activation?.type && act.activation.type !== "none")) {
            return true;
        }
    }

    const uses = item.system?.uses;
    if (uses && (uses.max > 0 || uses.per)) return true;

    return false;
}

// THIS LINE WAS MISSING 'export'
export function buildClassAbilitiesPane(actor, container) {
    if (!actor || !container) return;

    // Inject override styles for minimized state
    injectAbilitiesMinimizerStyles();

    const feats = actor.items.filter(i => i.type === "feat");

    if (!feats.length) {
        container.innerHTML = `
            <div style="font-size:11px; color:#888; text-align:center; padding:8px;">
                No features or traits found on this sheet.
            </div>
        `;
        return;
    }

    const classFeatures = [];
    const speciesTraits = [];
    const otherFeatures = [];

    feats.forEach(item => {
        const featType = item.system?.type?.value || "";
        
        if (featType === "class" || featType === "subclass") {
            classFeatures.push(item);
        } else if (featType === "race" || featType === "species") {
            speciesTraits.push(item);
        } else {
            otherFeatures.push(item);
        }
    });

    let html = `
        <div class="raug-abilities-container" style="
            display: grid; 
            grid-template-columns: repeat(4, 1fr); 
            gap: 10px; 
            padding: 4px; 
            max-height: 240px; 
            overflow-y: auto; 
            align-items: start;
        ">
            ${renderColumn(actor, "Class Features", "fa-shield-halved", "#c9b07a", classFeatures, 2)}
            ${renderColumn(actor, "Species Traits", "fa-dna", "#9dbd88", speciesTraits, 1)}
            ${renderColumn(actor, "Feats & Other", "fa-award", "#88a3bd", otherFeatures, 1)}
        </div>
    `;

    container.innerHTML = html;

    container.querySelectorAll(".raug-static-ability-btn").forEach(btn => {
        const itemId = btn.dataset.itemId;
        const item = actor.items.get(itemId);
        if (!item) return;

        btn.onclick = async (e) => {
            e.preventDefault();
            raugDebugLog("Left-clicked ability card (Use):", item.name);

            if (typeof item.use === "function") {
                await item.use();
            } else if (typeof item.roll === "function") {
                await item.roll();
            } else {
                item.sheet?.render(true);
            }
        };

        btn.oncontextmenu = (e) => {
            e.preventDefault();
            raugDebugLog("Right-clicked ability card (View Sheet):", item.name);
            item.sheet?.render(true);
        };
    });
}

function renderColumn(actor, title, iconClass, headerColor, items, colSpan) {
    const activeItems = items.filter(i => isItemActive(i));
    const passiveItems = items.filter(i => !isItemActive(i));

    let colHtml = `
        <div style="grid-column: span ${colSpan}; display: flex; flex-direction: column; gap: 6px; min-width: 0;">
            <strong style="color:${headerColor}; font-size:11px; display:block; margin-bottom:2px; font-weight:bold; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; border-bottom: 1px solid rgba(255,255,255,0.15); padding-bottom: 3px;">
                <i class="fas ${iconClass}"></i> ${title} (${items.length})
            </strong>
    `;

    if (!items.length) {
        colHtml += `<div style="font-size:10px; color:#666; font-style:italic; padding:2px;">None</div>`;
    } else {
        if (activeItems.length > 0) {
            colHtml += `
                <div style="display: flex; flex-direction: column; gap: 3px;">
                    <span style="font-size: 9px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; color: #d0d0d0; opacity: 0.7;">
                        <i class="fas fa-bolt" style="font-size: 8px;"></i> Active
                    </span>
                    <div style="display: grid; grid-template-columns: repeat(${colSpan}, 1fr); gap: 5px;">
            `;
            activeItems.forEach(item => {
                colHtml += renderButton(actor, item, headerColor, true);
            });
            colHtml += `</div></div>`;
        }

        if (passiveItems.length > 0) {
            colHtml += `
                <div style="display: flex; flex-direction: column; gap: 3px; ${activeItems.length > 0 ? 'margin-top: 4px;' : ''}">
                    <span style="font-size: 9px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; color: #a0a0a0; opacity: 0.6;">
                        <i class="fas fa-eye" style="font-size: 8px;"></i> Passive
                    </span>
                    <div style="display: grid; grid-template-columns: repeat(${colSpan}, 1fr); gap: 5px;">
            `;
            passiveItems.forEach(item => {
                colHtml += renderButton(actor, item, headerColor, false);
            });
            colHtml += `</div></div>`;
        }
    }

    colHtml += `</div>`;
    return colHtml;
}

function renderButton(actor, item, headerColor, isActive) {
    const uses = item.system?.uses;
    let usesText = "";
    if (uses && uses.max > 0) {
        usesText = ` <span style="font-size:9px; color:#c9b07a; font-weight:bold;">(${uses.value}/${uses.max})</span>`;
    }

    const sourceLabel = item.system?.type?.label || item.system?.requirements || (isActive ? "Active" : "Passive");
    const bgStyle = isActive ? "#1e1e24" : "#161619";
    const borderStyle = isActive ? "1px solid #3a3a42" : "1px dashed #2a2a30";
    const opacityStyle = isActive ? "1.0" : "0.8";

    // Clean description markup for player characters
    const rawDesc = item.system?.description?.value || "";
    const cleanDesc = clean5eDescriptionMarkup(rawDesc, actor);
    const descSnippet = cleanDesc ? `${cleanDesc.slice(0, 250)}${cleanDesc.length >= 250 ? "..." : ""}` : "No description available.";

    const tooltipText = `
        <div style="text-align: left; max-width: 250px; font-size: 11px; line-height: 1.3;">
            <strong style="color: #c9b07a; font-size: 12px; display: block; border-bottom: 1px solid #555; padding-bottom: 2px; margin-bottom: 4px;">
                ${item.name}
            </strong>
            <div style="font-size: 9px; color: #aaa; margin-bottom: 4px; font-style: italic;">
                Type: ${sourceLabel} | ${isActive ? 'Active Feature' : 'Passive Trait'}
            </div>
            <div style="color: #ddd;">
                ${descSnippet}
            </div>
            <div style="font-size: 9px; color: #888; margin-top: 6px; border-top: 1px dashed #444; padding-top: 2px;">
                <i class="fas fa-mouse-pointer"></i> Left-Click: Use | Right-Click: Sheet
            </div>
        </div>
    `.replace(/"/g, '&quot;');

    return `
        <button type="button" class="raug-static-ability-btn" data-item-id="${item.id}" data-tooltip="${tooltipText}" data-tooltip-direction="UP" style="
            background: ${bgStyle};
            color: #d6d6d6;
            border: ${borderStyle};
            opacity: ${opacityStyle};
            font-size: 11px;
            padding: 5px 6px;
            border-radius: 4px;
            cursor: pointer;
            text-align: left;
            display: flex;
            align-items: center;
            width: 100%;
            min-height: 38px;
            box-sizing: border-box;
            transition: background 0.15s ease, border-color 0.15s ease, opacity 0.15s ease;
        " onmouseover="this.style.background='#2a2a34'; this.style.borderColor='${headerColor}'; this.style.opacity='1.0';" onmouseout="this.style.background='${bgStyle}'; this.style.borderColor='${isActive ? '#3a3a42' : '#2a2a30'}'; this.style.opacity='${opacityStyle}';">
            <img src="${item.img}" style="width: 20px; height: 20px; margin-right: 6px; border: none; flex-shrink: 0; border-radius: 3px;"/>
            
            <div style="display: flex; flex-direction: column; min-width: 0; flex-grow: 1; line-height: 1.15;">
                <span style="
                    font-weight: 600; 
                    font-size: 10.5px; 
                    color: #e0e0e0;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                    word-break: break-word;
                ">${item.name}${usesText}</span>
                
                <span style="
                    font-size: 8.5px; 
                    color: #8a8a95; 
                    margin-top: 1px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                ">(${sourceLabel})</span>
            </div>
        </button>
    `;
}