// scripts/modules/paneConsumables.js
"use strict";

import { raugDebugLog } from "./state.js";

function clean5eDescriptionMarkup(text, actor) {
    if (!text) return "";
    let clean = text;
    const actorName = actor?.name || "the character";
    clean = clean.replace(/\{monster\}/gi, actorName);
    clean = clean.replace(/\[\[lookup\s+@[^\]]+\]\]/gi, actorName);
    clean = clean.replace(/@UUID\[[^\]]+\]\{([^}]+)\}/gi, "$1");
    clean = clean.replace(/@UUID\[[^\]]+\]/gi, "");
    clean = clean.replace(/\[\[\/item\s+([^\]]+)\]\]/gi, "$1");
    clean = clean.replace(/\[\[\/?[^\]]+\]\]/gi, "");
    return clean.replace(/<[^>]*>?/gm, "").trim();
}

/**
 * Audit global inventory and return categorized consumable buckets
 */
export function runGlobalInventoryAudit(actor) {
    if (!actor) return { potions: [], scrolls: [], mundane: [], foodWater: [] };

    const items = actor.items.filter(i => i.type === "consumable" || i.type === "loot");
    
    const potions = [];
    const scrolls = [];
    const foodWater = [];
    const mundane = [];

    items.forEach(item => {
        const consType = item.system?.type?.value || item.system?.consumableType || "";
        const nameLower = item.name.toLowerCase();

        if (consType === "potion" || nameLower.includes("potion") || nameLower.includes("elixir") || nameLower.includes("phial")) {
            potions.push(item);
        } else if (consType === "scroll" || nameLower.includes("scroll") || nameLower.includes("spell scroll")) {
            scrolls.push(item);
        } else if (nameLower.includes("ration") || nameLower.includes("water") || nameLower.includes("skin") || nameLower.includes("food") || nameLower.includes("drink")) {
            foodWater.push(item);
        } else {
            mundane.push(item);
        }
    });

    return { potions, scrolls, foodWater, mundane };
}

export function buildConsumablesHubPane(actor, container) {
    if (!actor || !container) return;

    const { potions, scrolls, foodWater, mundane } = runGlobalInventoryAudit(actor);

    container.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; padding: 4px; max-height: 240px; overflow-y: auto; align-items: start;">
            ${renderConsumableColumn(actor, "Potions & Elixirs", "fa-flask", "#e07a5f", potions, false)}
            ${renderConsumableColumn(actor, "Scrolls & Wands", "fa-scroll", "#f2cc8f", scrolls, false)}
            ${renderConsumableColumn(actor, "Rations & Water", "fa-utensils", "#81b29a", foodWater, true)}
            ${renderConsumableColumn(actor, "Mundane / Gear", "fa-boxes-stacked", "#3d405b", mundane, true)}
        </div>
    `;

    // Bind Left-Click (Use/Consume) and Right-Click (Open Sheet)
    container.querySelectorAll(".raug-consumable-btn").forEach(btn => {
        const itemId = btn.dataset.itemId;
        const isBulk = btn.dataset.isBulk === "true";
        const item = actor.items.get(itemId);
        if (!item) return;

        btn.onclick = async (e) => {
            e.preventDefault();
            if (isBulk) {
                promptBulkUsage(actor, item);
            } else {
                useConsumableSingle(actor, item, 1);
            }
        };

        btn.oncontextmenu = (e) => {
            e.preventDefault();
            item.sheet?.render(true);
        };
    });
}

function renderConsumableColumn(actor, title, iconClass, headerColor, items, isBulkAllowed) {
    let html = `
        <div style="display: flex; flex-direction: column; gap: 4px; min-width: 0;">
            <strong style="color:${headerColor}; font-size:11px; display:block; margin-bottom:2px; font-weight:bold; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; border-bottom: 1px solid rgba(255,255,255,0.15); padding-bottom: 3px;">
                <i class="fas ${iconClass}"></i> ${title} (${items.length})
            </strong>
    `;

    if (!items.length) {
        html += `<div style="font-size:10px; color:#666; font-style:italic; padding:2px;">None</div>`;
    } else {
        items.forEach(item => {
            const qty = item.system?.quantity ?? 1;
            const actType = item.system?.activation?.type;
            
            // Correct activation type readout (e.g. Bonus Action for potions)
            let actionText = "1 Action";
            if (actType === "bonus") actionText = "Bonus Action";
            else if (actType === "reaction") actionText = "Reaction";
            else if (actType === "minute" || actType === "hour") actionText = `${item.system?.activation?.cost || 1} ${actType}`;
            else if (!actType || actType === "none") actionText = "Free / Use";

            const rawDesc = item.system?.description?.value || "";
            const cleanDesc = clean5eDescriptionMarkup(rawDesc, actor);
            const descSnippet = cleanDesc ? `${cleanDesc.slice(0, 200)}${cleanDesc.length >= 200 ? "..." : ""}` : "No details.";

            const tooltipText = `
                <div style="text-align: left; max-width: 240px; font-size: 11px; line-height: 1.3;">
                    <strong style="color: #c9b07a; font-size: 12px; display: block; border-bottom: 1px solid #555; padding-bottom: 2px; margin-bottom: 4px;">
                        ${item.name}
                    </strong>
                    <div style="font-size: 9px; color: #aaa; margin-bottom: 4px;">
                        Quantity: <strong>${qty}</strong> | Activation: <strong>${actionText}</strong>
                    </div>
                    <div style="color: #ddd;">
                        ${descSnippet}
                    </div>
                </div>
            `.replace(/"/g, '&quot;');

            html += `
                <button type="button" class="raug-consumable-btn" data-item-id="${item.id}" data-is-bulk="${isBulkAllowed}" data-tooltip="${tooltipText}" data-tooltip-direction="UP" style="
                    background: #1a1a1e; color: #ddd; border: 1px solid #333; font-size: 10px; padding: 5px 6px;
                    border-radius: 3px; cursor: pointer; text-align: left; display: flex; align-items: center; justify-content: space-between;
                    width: 100%; box-sizing: border-box; transition: border-color 0.15s ease;
                " onmouseover="this.style.borderColor='${headerColor}'" onmouseout="this.style.borderColor='#333'">
                    <div style="display: flex; align-items: center; gap: 6px; overflow: hidden;">
                        <img src="${item.img}" style="width: 18px; height: 18px; border: none; border-radius: 2px; flex-shrink: 0;" />
                        <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 10.5px;">${item.name}</span>
                    </div>
                    <span style="font-size: 9.5px; color: #c9b07a; font-weight: bold; background: #2a2a30; padding: 1px 4px; border-radius: 3px; margin-left: 4px;">x${qty}</span>
                </button>
            `;
        });
    }

    html += `</div>`;
    return html;
}

async function useConsumableSingle(actor, item, count = 1) {
    const currentQty = item.system?.quantity ?? 1;
    
    if (typeof item.use === "function") {
        await item.use();
    } else if (typeof item.roll === "function") {
        await item.roll();
    }

    // Bookkeeping: Handle custom quantity deductions cleanly
    if (count > 1 && currentQty >= count) {
        const newQty = Math.max(0, currentQty - count);
        await item.update({ "system.quantity": newQty });
        
        ChatMessage.create({
            speaker: ChatMessage.getSpeaker({ actor }),
            content: `<div style="font-size: 11px;">Consumed <strong>${count}x ${item.name}</strong>. (Remaining: ${newQty})</div>`
        });
    }
}

/**
 * Bulk Use Dialog for Mundane Items (Rations, Water, Torches, etc.)
 */
function promptBulkUsage(actor, item) {
    const currentQty = item.system?.quantity ?? 1;

    const dialogContent = `
        <form style="display: flex; flex-direction: column; gap: 8px; font-size: 12px; padding: 4px;">
            <div>Use <strong>${item.name}</strong> (Available: ${currentQty}):</div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <label for="raug-bulk-qty">Amount:</label>
                <input type="number" id="raug-bulk-qty" name="qty" value="1" min="1" max="${currentQty}" style="width: 60px; text-align: center; background: #111; color: #fff; border: 1px solid #444; border-radius: 3px;" />
            </div>
        </form>
    `;

    new Dialog({
        title: `Consume Item: ${item.name}`,
        content: dialogContent,
        buttons: {
            use: {
                icon: '<i class="fas fa-check"></i>',
                label: "Confirm Use",
                callback: (html) => {
                    const count = parseInt(html.find('#raug-bulk-qty').val(), 10) || 1;
                    useConsumableSingle(actor, item, count);
                }
            },
            cancel: {
                icon: '<i class="fas fa-times"></i>',
                label: "Cancel"
            }
        },
        default: "use"
    }).render(true);
}