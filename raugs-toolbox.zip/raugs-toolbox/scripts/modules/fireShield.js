// scripts/modules/fireShield.js
"use strict";

import { logManualDamageContext } from "./intercepts.js";

export function getActiveFireShield(actor) {
    if (!actor) return null;

    const effects = actor.appliedEffects || actor.effects || [];
    
    for (const effect of effects) {
        if (effect.disabled) continue;
        const name = (effect.name || effect.label || "").toLowerCase();

        if (name.includes("warm shield")) {
            return { type: "fire", label: "Warm Shield (2d8 Fire)", icon: "fa-fire", color: "#d93838" };
        }
        if (name.includes("chill shield")) {
            return { type: "cold", label: "Chill Shield (2d8 Cold)", icon: "fa-snowflake", color: "#007acc" };
        }
    }

    return null;
}

export async function rollFireShieldRetaliation(actor, shieldInfo) {
    if (!actor || !shieldInfo) return;

    const damageType = shieldInfo.type; // "fire" or "cold"
    const formula = `2d8[${damageType}]`;
    const shieldName = damageType === "cold" ? "Chill Shield" : "Warm Shield";
    const flavorText = `<strong>Fire Shield Retaliation (${shieldName})</strong>`;

    let rollInstance = null;

    if (game.dnd5e?.dice?.DamageRoll) {
        rollInstance = new game.dnd5e.dice.DamageRoll(formula, {}, { damageType });
        await rollInstance.evaluate();
    } else {
        rollInstance = new Roll(formula);
        await rollInstance.evaluate();
    }

    const rollTotal = Number(rollInstance.total || 0);

    // Capitalize type string ("Cold" / "Fire") to match Extra Damage breakdown formatting
    const formattedType = damageType.charAt(0).toUpperCase() + damageType.slice(1);

    // Get active target tokens
    const targetTokens = Array.from(game.user.targets);

    // Provide actor UUID alongside explicit name and image for dnd5e target element rendering
    const dnd5eTargetData = targetTokens
        .map(t => {
            const tokenDoc = t.document || t;
            const targetActor = tokenDoc.actor;
            if (!targetActor) return null;

            return {
                uuid: targetActor.uuid,
                name: tokenDoc.name || targetActor.name,
                img: tokenDoc.texture?.src || targetActor.img
            };
        })
        .filter(Boolean);

    // Extract metadata for RAUG's tracking engine
    const targetInfo = targetTokens.map(t => {
        const tokenDoc = t.document || t;
        const targetActor = tokenDoc.actor;
        if (!targetActor) return null;

        return {
            name: tokenDoc.name || targetActor.name,
            img: tokenDoc.texture?.src || targetActor.img,
            uuid: tokenDoc.uuid,
            ac: targetActor.system?.attributes?.ac?.value ?? null,
            id: targetActor.id
        };
    }).filter(Boolean);

    // Matches the exact array shape expected by paneTracker (type & total)
    const damageDetails = [{ type: damageType, total: rollTotal }];

    const msg = await rollInstance.toMessage({
        speaker: ChatMessage.getSpeaker({ actor }),
        flavor: flavorText,
        flags: {
            raug: { 
                isManualShieldRoll: true,
                itemName: `Fire Shield (${shieldName})`
            },
            dnd5e: {
                roll: { type: "damage" },
                targets: dnd5eTargetData
            }
        }
    });

    if (msg?.id) {
        logManualDamageContext(
            actor, 
            `Fire Shield (${shieldName})`, 
            rollTotal, 
            false, 
            formattedType, 
            msg.id, 
            damageDetails
        );
    }
}