// scripts/modules/state.js
"use strict";

export const RAUG_MODULE_ID = "raugs-toolbox";
export const RAUG_TAB_BTN = "flex:1; padding:6px 6px; line-height:1.3; font-size:10px; font-weight:bold; border-radius:3px; cursor:pointer;";
export const RAUG_TAB_ACTIVE = `${RAUG_TAB_BTN} background:#262626; color:#c9b07a; border:1px solid #444;`;
export const RAUG_TAB_IDLE = `${RAUG_TAB_BTN} background:#1a1a1a; color:#aaa; border:1px solid #333;`;
export const RAUG_CAT_BTN = "padding:6px 8px; line-height:1.3; font-weight:bold; font-size:10px; background:#262626; color:#e0d6bd; border:1px solid #444; border-radius:4px; cursor:pointer;";

window.RAUG_TOOLKIT_DEBUG = window.RAUG_TOOLKIT_DEBUG ?? false;
window.RAUG_ACTIVE_CONTEXTS = window.RAUG_ACTIVE_CONTEXTS ?? [];
window.RAUG_TRAY_STATE = window.RAUG_TRAY_STATE ?? {};

Hooks.once("init", () => {
    game.settings.register(RAUG_MODULE_ID, "globalCombatContexts", {
        name: "Global Combat Logs",
        scope: "world",
        config: false,
        type: Array,
        default: []
    });

    game.settings.register(RAUG_MODULE_ID, "globalSessionAnchor", {
        name: "Global Session Anchor Timestamp",
        scope: "world",
        config: false,
        type: Number,
        default: 0
    });
});

export function raugDebugLog(...args) {
    if (window.RAUG_TOOLKIT_DEBUG) console.log("RaugDebug:", ...args);
}

export function getRaugTrayState(actorId) {
    return window.RAUG_TRAY_STATE[actorId] ?? { expanded: false, tab: "combat", consumableMode: null };
}

export function setRaugTrayState(actorId, patch) {
    if (!actorId) return;
    window.RAUG_TRAY_STATE[actorId] = { ...getRaugTrayState(actorId), ...patch };
}

export function raugSourceLabel(ctx) {
    const sourceName = ctx.sourceName || ctx.actorName || "Unknown Source";
    const actionName = ctx.name || "Action";
    const targetName = ctx.targetName ? ` ➔ ${ctx.targetName}` : "";
    return `${sourceName} (${actionName})${targetName}`;
}

export function raugRollTotal(result) {
    if (!result) return NaN;
    const roll = Array.isArray(result) ? result[0] : result;
    return Number(roll?.total ?? NaN);
}

export function raugRollIsCrit(result) {
    if (!result) return false;
    const roll = Array.isArray(result) ? result[0] : result;
    return !!(roll?.isCritical || roll?.options?.isCritical);
}

export function raugDamageOnSave(total, passed, onSave) {
    if (!passed) return total;
    if (onSave === "none") return 0;
    if (onSave === "full") return total;
    return Math.floor(total / 2);
}