// scripts/modules/chatBookkeeping.js
"use strict";

import { raugDebugLog } from "./state.js";

function getOrdinalSuffix(n) {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

function getStatusColor(remaining, max) {
    if (remaining <= 0) return "#d93838"; // Red
    if (remaining === 1) return "#d97706"; // Orange
    if (remaining >= max && max > 0) return "#2b8a3e"; // Green
    return "#191813"; // Neutral Dark
}

// Comprehensive Friendly Name Overrides for All Core Class Resources / Pools
function formatResourceLabel(rawName, path = "") {
    const cleanName = (rawName || "").trim().toLowerCase();
    const cleanPath = (path || "").trim().toLowerCase();
    
    // Barbarian
    if (cleanName.includes("relentless rage")) {
        return "Relentless Rage";
    }
    if (cleanName === "rage" || (cleanName.includes("rage") && !cleanName.includes("relentless"))) {
        return "Rages";
    }

    // Bard
    if (cleanName.includes("bardic inspiration") || cleanName.includes("inspiration")) {
        return "Bardic Inspiration";
    }

    // Cleric / Paladin
    if (cleanName.includes("channel divinity")) {
        return "Channel Divinity";
    }
    if (cleanName.includes("lay on hands")) {
        return "Lay on Hands Pool";
    }
    if (cleanName.includes("divine intervention")) {
        return "Divine Intervention";
    }

    // Druid
    if (cleanName.includes("wild shape") || cleanName.includes("wildshape")) {
        return "Wild Shape";
    }

    // Fighter
    if (cleanName.includes("action surge")) {
        return "Action Surge";
    }
    if (cleanName.includes("second wind")) {
        return "Second Wind";
    }
    if (cleanName.includes("superiority dice") || cleanName.includes("superiority die") || cleanName.includes("maneuvers")) {
        return "Superiority Dice";
    }

    // Monk
    if (
        cleanName.includes("ki") || 
        cleanName.includes("focus point") || 
        cleanName.includes("monk's focus") || 
        cleanName.includes("monk focus") ||
        cleanPath.includes("resources.ki") ||
        cleanPath.includes("resources.focus")
    ) {
        return "Ki Points";
    }

    // Paladin
    if (cleanName.includes("divine sense")) {
        return "Divine Sense";
    }

    // Sorcerer (Strict match to avoid loose 'sp' string hits)
    if (
        cleanName.includes("font of magic") || 
        cleanName.includes("sorcery point") || 
        cleanName === "sorcery points" ||
        cleanPath.includes("resources.sorcery") ||
        cleanPath.includes("resources.sp")
    ) {
        return "Sorcery Points";
    }

    // Warlock
    if (cleanName.includes("eldritch master") || cleanName.includes("mystic arcanum")) {
        return "Arcanum Uses";
    }

    // Gunslinger / Homebrew Common Mechanics
    if (cleanName.includes("grit") || cleanName.includes("panache")) {
        return "Grit/Panache";
    }

    // Fallback formatting
    return rawName ? rawName.charAt(0).toUpperCase() + rawName.slice(1) : "";
}

export async function handleResourceUseViaWrapper(actor, item, useResult = {}, activity = null, config = {}) {
    if (!actor || !item) return;

    // Allowed time for modal dialogs (healing rolls, inputs) to update actor data
    setTimeout(async () => {
        try {
            await processBookkeepingAppend(actor, item, useResult, activity, config);
        } catch (err) {
            console.error("RAUG | Error processing bookkeeping card:", err);
        }
    }, 300);
}

async function processBookkeepingAppend(actor, item, useResult, activity, config) {
    const itemType = item.type;
    let resourceLines = [];
    const sys = item.system || {};
    const actionType = sys.activation?.type || activity?.activation?.type || "";

    // ----------------------------------------------------
    // 1. SPELLS & SPELL SLOTS
    // ----------------------------------------------------
    if (itemType === "spell") {
        const baseLevel = Number(sys.level ?? 0);
        let castLevel = null;

        const spellMethod = sys.method || sys.preparation?.mode || "";
        let isPact = spellMethod === "pact";

        const spellConfig = config?.use?.spell || config?.spell || {};
        const slotChoice = spellConfig.slot || config?.consumption?.spellSlot;

        if (typeof slotChoice === "string") {
            if (slotChoice === "pact") {
                isPact = true;
                castLevel = Number(actor.system?.spells?.pact?.level ?? baseLevel);
            } else if (slotChoice.startsWith("spell")) {
                castLevel = Number(slotChoice.replace("spell", ""));
            }
        } else if (Number.isFinite(Number(slotChoice))) {
            castLevel = Number(slotChoice);
        }

        if (!castLevel && spellConfig.level) {
            castLevel = Number(spellConfig.level);
        }

        if (!castLevel) {
            const actorUpdates = useResult?.updates?.actor || {};
            for (const key of Object.keys(actorUpdates)) {
                if (key.includes("system.spells.spell")) {
                    const match = key.match(/system\.spells\.spell(\d+)\.value/);
                    if (match) castLevel = Number(match[1]);
                } else if (key.includes("system.spells.pact")) {
                    isPact = true;
                    castLevel = Number(actor.system?.spells?.pact?.level ?? baseLevel);
                }
            }
        }

        if (castLevel === null || castLevel === undefined) {
            castLevel = baseLevel;
        }

        resourceLines.push(`${actor.name} cast <strong>${item.name}</strong>`);

        if (castLevel === 0) {
            resourceLines.push(`Spell Slot Used: <strong>Cantrip</strong>`);
        } else {
            let levelLabel = `${getOrdinalSuffix(castLevel)}`;
            if (castLevel > baseLevel && baseLevel > 0) {
                levelLabel += ` (Upcast from ${getOrdinalSuffix(baseLevel)})`;
            }

            const slotKey = isPact ? "pact" : `spell${castLevel}`;
            const slotData = actor.system?.spells?.[slotKey];

            resourceLines.push(`Spell Slot Used: <strong>${levelLabel}${isPact ? " [Pact]" : ""}</strong>`);

            if (slotData) {
                const rem = slotData.value ?? 0;
                const max = slotData.max ?? 0;
                const color = getStatusColor(rem, max);
                
                const slotTitle = isPact ? "Pact Slots" : `${getOrdinalSuffix(castLevel)}-Level Spell Slots`;
                resourceLines.push(`${slotTitle} Remaining: <strong style="color:${color};">${rem}/${max}</strong>`);
            }
        }
    } 
    // ----------------------------------------------------
    // 2. CLASS FEATURES, METAMAGIC & FEATS
    // ----------------------------------------------------
    else if (itemType === "feat") {
        let featureName = item.name;
        if (activity?.name && activity.name !== item.name && !item.name.toLowerCase().includes(activity.name.toLowerCase())) {
            featureName = `${item.name} (${activity.name})`;
        }
        
        resourceLines.push(`${actor.name} used <strong>${featureName}</strong>`);

        const cleanItemName = item.name.toLowerCase();

        // A. Relentless Rage Handler
        if (cleanItemName.includes("relentless rage")) {
            const currentDC = actor.getFlag("raug", "relentlessRageDC") ?? 10;
            resourceLines.push(`Constitution Save DC: <strong>DC ${currentDC}</strong>`);
            
            const nextDC = currentDC + 5;
            await actor.setFlag("raug", "relentlessRageDC", nextDC);
            resourceLines.push(`Next Relentless Rage DC: <strong style="color:#d97706;">DC ${nextDC}</strong>`);
        } 
        // B. Greater Divine Intervention Handler
        else if (cleanItemName.includes("greater divine intervention")) {
            const roll2d4 = new Roll("2d4");
            await roll2d4.evaluate();
            const restsNeeded = roll2d4.total;

            await actor.setFlag("raug", "greaterDivineInterventionCooldown", restsNeeded);
            resourceLines.push(`Cooldown Triggered: <strong style="color:#d93838;">2d4 Long Rests (${restsNeeded} remaining)</strong>`);
        }
        // C. Standard Divine Intervention Handler
        else if (cleanItemName.includes("divine intervention")) {
            resourceLines.push(`Status: <strong style="color:#d97706;">Cooldown active until Long Rest</strong>`);
        }
        // D. General Feature Charge Tracking
        else {
            const liveItem = actor.items.get(item.id) || item;
            const uses = liveItem.system?.uses || sys.uses || {};
            
            const consumptionTargets = [];
            if (sys.consume?.target) consumptionTargets.push(sys.consume);
            if (activity?.consumption?.targets?.length) {
                consumptionTargets.push(...activity.consumption.targets);
            }

            // Direct Uses
            if (uses.max || uses.max > 0) {
                const rem = uses.value ?? 0;
                const max = uses.max ?? 0;
                const color = getStatusColor(rem, max);
                
                const customLabel = formatResourceLabel(item.name, item.id);
                const labelText = customLabel ? `${customLabel} Remaining` : `Uses Remaining`;

                resourceLines.push(`${labelText}: <strong style="color:${color};">${rem}/${max}</strong>`);
            } 
            
            // Explicit Consumption Targets
            if (consumptionTargets.length > 0) {
                for (const target of consumptionTargets) {
                    const targetPath = target.target;
                    const type = target.type;

                    if (!targetPath) continue;

                    if (type === "attribute" || targetPath.includes("resources.") || targetPath.includes("system.")) {
                        const cleanPath = targetPath.replace(/^system\./, "");
                        const resData = foundry.utils.getProperty(actor.system, cleanPath.replace(/\.value$/, ""));

                        if (resData && typeof resData === "object") {
                            const rem = resData.value ?? 0;
                            const max = resData.max ?? 0;
                            const color = getStatusColor(rem, max);

                            let rawResName = "Resource";
                            if (cleanPath.includes("resources.")) {
                                const resKey = cleanPath.split(".")[1];
                                rawResName = actor.system.resources[resKey]?.label || resKey;
                            } else {
                                const parts = cleanPath.split(".");
                                rawResName = parts[parts.length - 1] === "value" ? parts[parts.length - 2] : parts[parts.length - 1];
                            }

                            const resName = formatResourceLabel(rawResName, cleanPath);
                            const displayStr = max > 0 ? `${rem}/${max}` : `${rem}`;
                            resourceLines.push(`${resName} Remaining: <strong style="color:${color};">${displayStr}</strong>`);
                        }
                    } else if (type === "itemUses" || type === "material") {
                        if (targetPath === item.id) continue;

                        const consumedItem = actor.items.get(targetPath);
                        if (consumedItem) {
                            const rem = consumedItem.system?.uses?.value ?? consumedItem.system?.quantity ?? 0;
                            const max = consumedItem.system?.uses?.max ?? 0;
                            const color = getStatusColor(rem, max);
                            const displayCount = max > 0 ? `${rem}/${max}` : `${rem}`;
                            
                            const resName = formatResourceLabel(consumedItem.name, targetPath);
                            resourceLines.push(`${resName} Remaining: <strong style="color:${color};">${displayCount}</strong>`);
                        }
                    }
                }
            }
        }
    } 
    // ----------------------------------------------------
    // 3. CONSUMABLES, LOOT & AMMO
    // ----------------------------------------------------
    else if (itemType === "consumable" || itemType === "loot" || itemType === "ammo") {
        const liveItem = actor.items.get(item.id);
        const remQty = liveItem?.system?.quantity ?? liveItem?.system?.uses?.value ?? 0;
        const color = remQty <= 0 ? "#d93838" : remQty === 1 ? "#d97706" : "#191813";

        resourceLines.push(`Consumed: <strong>${item.name}</strong>`);
        resourceLines.push(`Quantity Remaining: <strong style="color:${color};">${remQty}</strong>`);
    }

    if (!resourceLines.length) return;

    let targetMessage = useResult?.chat?.message 
        || useResult?.message 
        || (useResult instanceof ChatMessage ? useResult : null);

    if (!targetMessage) {
        const recentMsgs = game.messages.contents.slice(-5).reverse();
        targetMessage = recentMsgs.find(m => 
            (m.speaker?.actor === actor.id || m.actor?.id === actor.id) && 
            (Date.now() - m.timestamp < 5000)
        );
    }

    if (targetMessage) {
        if (targetMessage.content.includes("raug-bookkeeping-footer")) return;

        const actionBadge = actionType 
            ? `<span style="text-transform:capitalize; color:#555;">Action: ${actionType}</span>` 
            : `<span style="color:#777;">No Action</span>`;

        const linesHtml = resourceLines.map(line => `<div>${line}</div>`).join("");

        const ledgerHtml = `<div class="raug-bookkeeping-footer" style="margin-top: 6px; padding: 4px 6px; background: transparent; border-left: 3px solid #7a7971; font-size: 11px; line-height: 1.4; color: #191813;">${linesHtml}<div style="margin-top: 4px; font-size: 10px; border-top: 1px dotted rgba(0,0,0,0.2); padding-top: 3px;">${actionBadge}</div></div>`;

        const textEditor = foundry.applications?.ux?.TextEditor?.implementation || TextEditor;
        const enriched = await textEditor.enrichHTML(ledgerHtml, { async: true });
        
        await targetMessage.update({ content: targetMessage.content + enriched });
        raugDebugLog("Bookkeeping appended to chat message:", targetMessage.id);
    }
}

// Rest Hook Handler: Resets DCs & decrements multi-rest cooldowns
Hooks.on("dnd5e.restCompleted", async (actor, restData) => {
    if (!actor) return;

    // Reset Relentless Rage DC
    if (actor.getFlag("raug", "relentlessRageDC")) {
        await actor.setFlag("raug", "relentlessRageDC", 10);
    }

    // Process Greater Divine Intervention long rest counter
    if (restData?.longRest) {
        const gdiCooldown = actor.getFlag("raugs-toolbox", "greaterDivineInterventionCooldown");
        if (gdiCooldown && gdiCooldown > 0) {
            const remaining = gdiCooldown - 1;
            if (remaining <= 0) {
                await actor.unsetFlag("raug", "greaterDivineInterventionCooldown");
            } else {
                await actor.setFlag("raug", "greaterDivineInterventionCooldown", remaining);
            }
        }
    }
});

Hooks.once("ready", () => {
    Hooks.on("dnd5e.postUseActivity", (activity, config, results) => {
        if (activity?.actor && activity?.item) {
            handleResourceUseViaWrapper(activity.actor, activity.item, results, activity, config);
        }
    });
});