"use strict";

/**
 * Multiattack parser handling additive sequences ("and"), choices ("or"),
 * and complex dragon replacement clauses.
 */
export function parseMultiattackRoutine(actor) {
    const multiItem = actor.items.find(i => i.name.toLowerCase() === "multiattack");
    if (!multiItem) return null;

    const rawDesc = multiItem.system?.description?.value || "";

    // 1. Clean HTML & normalize written numbers to digits
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = rawDesc;
    let cleanDesc = (tempDiv.textContent || tempDiv.innerText || "")
        .replace(/\u00a0/g, " ")
        .replace(/\s+/g, " ")
        .trim();

    const wordMap = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6 };
    Object.keys(wordMap).forEach(word => {
        const reg = new RegExp(`\\b${word}\\b`, "gi");
        cleanDesc = cleanDesc.replace(reg, wordMap[word]);
    });

    const isValidItem = (item) => {
        if (!item || item === multiItem) return false;
        const name = item.name.toLowerCase();
        return name !== "spellcasting" && !name.includes("spellcasting");
    };

    const validItems = actor.items.filter(isValidItem);

    // Extract declared base attack total ("makes 3 attacks")
    let baseAttackCount = 0;
    const totalCountMatch = cleanDesc.match(/makes\s+(\d+)\s+.*attack/i) || cleanDesc.match(/\b(\d+)\b(?=.*attack)/i);
    if (totalCountMatch) {
        baseAttackCount = parseInt(totalCountMatch[1], 10);
    }

    // 2. Locate all valid item occurrences in text
    const itemMatches = [];
    validItems.forEach(item => {
        const cleanName = item.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const reg = new RegExp(`(?:(\\d+)\\s+)?(?:[\\w-]+\\s+)*(?:with|using)?\\s*(?:its|a|an|the)?\\s*(${cleanName})(?:s|es)?\\b`, "gi");
        
        let m;
        while ((m = reg.exec(cleanDesc)) !== null) {
            itemMatches.push({
                index: m.index,
                length: m[0].length,
                count: parseInt(m[1] || "1", 10),
                item
            });
        }
    });

    itemMatches.sort((a, b) => a.index - b.index);
    if (itemMatches.length === 0) return null;

    const hasReplacementClause = /replace\s+(?:\d+|1|an?)\s+attack/i.test(cleanDesc);

    // 3. Evaluate AND vs OR / Replacement clauses
    let sequenceSteps = [];
    let isStrictSequence = true;
    const availableItemsMap = new Map();

    if (hasReplacementClause) {
        // Dragon / Flexible Replacement Mode
        isStrictSequence = false;
        validItems.forEach(item => {
            const cleanName = item.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            if (new RegExp(`\\b${cleanName}(?:s|es)?\\b`, "i").test(cleanDesc)) {
                const isRestricted = new RegExp(`replace\\s+(?:\\d+|1|an?)\\s+attack.*${cleanName}`, "i").test(cleanDesc);
                if (!availableItemsMap.has(item.id)) {
                    availableItemsMap.set(item.id, { item, name: item.name, isRestricted });
                }
            }
        });
    } else if (itemMatches.length > 1) {
        let hasInterveningAnd = false;

        for (let i = 0; i < itemMatches.length - 1; i++) {
            const endOfFirst = itemMatches[i].index + itemMatches[i].length;
            const startOfNext = itemMatches[i + 1].index;
            const interveningText = cleanDesc.slice(endOfFirst, startOfNext).toLowerCase();

            if (interveningText.includes("and")) {
                hasInterveningAnd = true;
                break;
            }
        }

        if (hasInterveningAnd) {
            // Additive mode ("1 Bite AND 1 Claw")
            itemMatches.forEach(m => {
                for (let c = 0; c < m.count; c++) {
                    sequenceSteps.push({ item: m.item, name: m.item.name });
                }
                if (!availableItemsMap.has(m.item.id)) {
                    availableItemsMap.set(m.item.id, { item: m.item, name: m.item.name, isRestricted: false });
                }
            });
        } else {
            // Choice mode ("1 Bite OR 1 Claw")
            isStrictSequence = false;
            itemMatches.forEach(m => {
                if (!availableItemsMap.has(m.item.id)) {
                    availableItemsMap.set(m.item.id, { item: m.item, name: m.item.name, isRestricted: false });
                }
            });
        }
    } else {
        // Single attack type with explicit count
        const m = itemMatches[0];
        for (let c = 0; c < m.count; c++) {
            sequenceSteps.push({ item: m.item, name: m.item.name });
        }
        availableItemsMap.set(m.item.id, { item: m.item, name: m.item.name, isRestricted: false });
    }

    return {
        multiItem,
        totalSteps: isStrictSequence ? sequenceSteps.length : (baseAttackCount || 1),
        sequenceSteps,
        availableItems: Array.from(availableItemsMap.values()),
        isStrictSequence
    };
}

export class MultiattackWizard {
    constructor(actor, routineData) {
        this.actor = actor;
        this.totalSteps = routineData.totalSteps;
        this.availableItems = routineData.availableItems;
        this.sequenceSteps = routineData.sequenceSteps || [];
        this.isStrictSequence = routineData.isStrictSequence;
        this.currentStep = 1;
        this.usedRestricted = new Set();
        this.lastRolledItem = null;
        this.lastActivity = null;
        this.app = null;
    }

    static async start(actor) {
        const routine = parseMultiattackRoutine(actor);
        if (!routine || (!routine.availableItems.length && !routine.sequenceSteps?.length)) {
            return ui.notifications.warn(`Could not parse Multiattack options for ${actor.name}.`);
        }

        if (routine.multiItem) {
            if (typeof routine.multiItem.use === "function") {
                await routine.multiItem.use({ configure: false });
            } else if (typeof routine.multiItem.roll === "function") {
                await routine.multiItem.roll();
            }
        }

        const wizard = new MultiattackWizard(actor, routine);
        wizard.render();
    }

    render() {
        const content = this.buildHtml();

        if (this.app) {
            const el = this.app.element instanceof HTMLElement ? this.app.element : this.app.element[0];
            const innerContainer = el.querySelector(".raug-multi-wizard-container");
            if (innerContainer) {
                innerContainer.outerHTML = content;
                this.bindEvents(el);
                return;
            }
        }

        this.app = new Dialog({
            title: `Multiattack: ${this.actor.name}`,
            content: `<div class="raug-multi-wizard-wrapper">${content}</div>`,
            buttons: {
                close: { label: "Close Sequence", icon: '<i class="fas fa-times"></i>' }
            },
            default: "close",
            render: (html) => {
                const root = html instanceof HTMLElement ? html : html[0];
                this.bindEvents(root);
            }
        }, { width: 480, classes: ["dnd5e2", "sheet", "raug-multi-dialog"] });

        this.app.render(true);
    }

    buildHtml() {
        let flowchartHtml = `<div style="display: flex; justify-content: space-around; align-items: center; margin-bottom: 12px; background: #111; padding: 8px; border-radius: 4px; border: 1px solid #333;">`;

        for (let i = 1; i <= this.totalSteps; i++) {
            const isCurrent = i === this.currentStep;
            const isDone = i < this.currentStep;

            const borderStyle = isCurrent ? "2px solid #c9b07a" : (isDone ? "1px solid #2e7d32" : "1px solid #444");
            const bgStyle = isCurrent ? "rgba(201, 176, 122, 0.15)" : (isDone ? "rgba(46, 125, 50, 0.15)" : "#181818");
            const color = isCurrent ? "#c9b07a" : (isDone ? "#81c784" : "#666");

            let stepOptionsText = "";
            if (this.isStrictSequence && this.sequenceSteps[i - 1]) {
                stepOptionsText = this.sequenceSteps[i - 1].name;
            } else {
                stepOptionsText = "Flexible Choice";
            }

            flowchartHtml += `
                <div style="text-align: center; flex: 1; border: ${borderStyle}; background: ${bgStyle}; padding: 6px 4px; margin: 0 3px; border-radius: 4px; min-width: 0;">
                    <div style="font-size: 11px; font-weight: bold; color: ${color}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Attack ${i}</div>
                    <div style="font-size: 8.5px; color: #aaa; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">${stepOptionsText}</div>
                    <div style="font-size: 8px; color: ${isDone ? '#81c784' : '#666'}; text-transform: uppercase; margin-top: 1px;">${isDone ? "✓ Done" : (isCurrent ? "Active" : "Pending")}</div>
                </div>
            `;
            if (i < this.totalSteps) {
                flowchartHtml += `<i class="fas fa-chevron-right" style="color: #444; font-size: 9px;"></i>`;
            }
        }
        flowchartHtml += `</div>`;

        let buttonsHtml = `<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 8px; margin-bottom: 12px;">`;

        if (this.isStrictSequence) {
            const currentStepTarget = this.sequenceSteps[this.currentStep - 1];
            if (currentStepTarget) {
                const { item } = currentStepTarget;
                buttonsHtml += `
                    <button type="button" class="raug-wizard-action-btn" data-item-id="${item.id}" style="
                        grid-column: 1 / -1; background: #222; color: #e0e0e0; border: 1px solid #c9b07a; padding: 10px; border-radius: 4px; font-weight: bold; font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;
                    ">
                        <img src="${item.img}" style="width: 18px; height: 18px; border: none; border-radius: 2px;" />
                        <span>Execute: ${item.name}</span>
                    </button>
                `;
            }
        } else {
            this.availableItems.forEach(({ item, isRestricted }) => {
                const isSpent = isRestricted && this.usedRestricted.has(item.id);
                const disabledAttr = isSpent ? "disabled" : "";
                const opacity = isSpent ? "opacity: 0.35; cursor: not-allowed;" : "cursor: pointer;";
                const tag = isSpent ? " (Used)" : "";

                buttonsHtml += `
                    <button type="button" class="raug-wizard-action-btn" data-item-id="${item.id}" ${disabledAttr} style="
                        background: #222; color: #eee; border: 1px solid #444; padding: 8px; border-radius: 4px; font-weight: bold; font-size: 11px; ${opacity} display: flex; align-items: center; justify-content: center; gap: 6px;
                    ">
                        <img src="${item.img}" style="width: 16px; height: 16px; border: none; border-radius: 2px;" />
                        <span>${item.name}${tag}</span>
                    </button>
                `;
            });
        }
        buttonsHtml += `</div>`;

        let footerControls = "";
        if (this.lastRolledItem) {
            footerControls = `
                <div style="display: flex; gap: 8px; border-top: 1px dashed #444; padding-top: 10px; margin-top: 6px;">
                    <button type="button" class="raug-wizard-dmg-btn" style="flex: 1; background: #7a0000; color: #fff; border: 1px solid #999; padding: 6px; border-radius: 3px; font-weight: bold; font-size: 11px; cursor: pointer;">
                        <i class="fas fa-dice-d20"></i> Roll Damage (${this.lastRolledItem.name})
                    </button>
                    <button type="button" class="raug-wizard-next-btn" style="flex: 1; background: #1b6b33; color: #fff; border: 1px solid #999; padding: 6px; border-radius: 3px; font-weight: bold; font-size: 11px; cursor: pointer;">
                        Next Attack <i class="fas fa-forward"></i>
                    </button>
                </div>
            `;
        }

        return `
            <div class="raug-multi-wizard-container" style="font-family: sans-serif; color: #e0e0e0; padding: 4px;">
                <div style="font-size: 11px; font-weight: bold; color: #c9b07a; margin-bottom: 8px; text-align: center;">
                    Multiattack Sequence (Attack ${this.currentStep} of ${this.totalSteps})
                </div>
                ${flowchartHtml}
                <div style="font-size: 10px; color: #888; margin-bottom: 6px;">
                    Select option for Attack ${this.currentStep}:
                </div>
                ${buttonsHtml}
                ${footerControls}
            </div>
        `;
    }

    bindEvents(root) {
        root.querySelectorAll(".raug-wizard-action-btn").forEach(btn => {
            btn.onclick = async (e) => {
                e.preventDefault();
                const itemId = btn.dataset.itemId;
                const item = this.actor.items.get(itemId);
                if (!item) return;

                const entry = this.availableItems.find(i => i.item.id === itemId);
                if (entry?.isRestricted) {
                    this.usedRestricted.add(item.id);
                }

                const targetType = item.system?.target?.type;
                const hasAreaTarget = ["cone", "cube", "cylinder", "line", "radius", "sphere", "square"].includes(targetType);

                if (hasAreaTarget && this.app) {
                    this.app.minimize();

                    const templateHookId = Hooks.once("createMeasuredTemplate", () => {
                        if (this.app) {
                            this.app.maximize();
                            this.render();
                        }
                    });

                    setTimeout(() => {
                        Hooks.off("createMeasuredTemplate", templateHookId);
                        if (this.app && this.app._minimized) this.app.maximize();
                    }, 15000);
                }

                this.lastRolledItem = item;
                let isAttackRoll = false;

                if (item.system?.activities && item.system.activities.size > 0) {
                    const activities = Array.from(item.system.activities.values());
                    const attackAct = activities.find(a => a.type === "attack") || activities[0];
                    this.lastActivity = attackAct;

                    if (attackAct.type === "attack" && typeof attackAct.rollAttack === "function") {
                        isAttackRoll = true;
                        await attackAct.rollAttack({}, { event: e });
                    } else {
                        await attackAct.use({ configure: false }, { event: e });
                    }
                } else if (typeof item.rollAttack === "function") {
                    isAttackRoll = true;
                    await item.rollAttack({ event: e });
                } else if (typeof item.use === "function") {
                    await item.use({ configure: false }, { event: e });
                } else if (typeof item.roll === "function") {
                    await item.roll({ event: e });
                }

                if (!isAttackRoll) {
                    this.advanceStep();
                } else {
                    this.render();
                }
            };
        });

        root.querySelector(".raug-wizard-dmg-btn")?.addEventListener("click", async (e) => {
            e.preventDefault();
            if (!this.lastRolledItem) return;

            const item = this.lastRolledItem;

            if (this.lastActivity && typeof this.lastActivity.rollDamage === "function") {
                await this.lastActivity.rollDamage({}, { event: e });
            } else if (item.system?.activities && item.system.activities.size > 0) {
                const dmgAct = Array.from(item.system.activities.values()).find(a => a.type === "damage") 
                            || Array.from(item.system.activities.values())[0];
                if (dmgAct && typeof dmgAct.rollDamage === "function") {
                    await dmgAct.rollDamage({}, { event: e });
                }
            } else if (typeof item.rollDamage === "function") {
                await item.rollDamage({ event: e });
            }

            this.advanceStep();
        });

        root.querySelector(".raug-wizard-next-btn")?.addEventListener("click", (e) => {
            e.preventDefault();
            this.advanceStep();
        });
    }

    advanceStep() {
        this.currentStep++;
        this.lastRolledItem = null;
        this.lastActivity = null;

        if (this.currentStep > this.totalSteps) {
            ui.notifications.info(`Multiattack sequence completed for ${this.actor.name}.`);
            if (this.app) this.app.close();
            return;
        }

        this.render();
    }
}