"use strict";

import { RAUG_MODULE_ID } from "./state.js";
import { logManualDamageContext, parseDamageBreakdown } from "./intercepts.js";

const MODULE_SCOPE = RAUG_MODULE_ID || "raugs-toolbox";
const FLAG_LUNAR_LOCK = "lunarFormUsedThisTurn";
const FLAG_FURY_LOCK = "elementalFuryUsedThisTurn";
const FLAG_CME_TYPE = "cmeDamageType";
const FLAG_CME_LEVEL = "cmeCastLevel";
const FLAG_FURY_TYPE = "furyDamageType";

export async function resetExtraDamageTurnLocks(actor) {
    if (!actor) return;
    await actor.unsetFlag(MODULE_SCOPE, FLAG_LUNAR_LOCK);
    await actor.unsetFlag(MODULE_SCOPE, FLAG_FURY_LOCK);
    ui.notifications.info(`Reset turn locks for ${actor.name}.`);
}

export async function promptExtraDamageIfEligible(actor, rollsOrActivity, autoCheckReset = false) {
    if (!actor) return;

    let subject = rollsOrActivity;
    if (Array.isArray(rollsOrActivity)) {
        const firstRoll = rollsOrActivity[0];
        subject = firstRoll?.options?.subject || firstRoll?.data?.item || firstRoll;
    } else if (rollsOrActivity?.options?.subject) {
        subject = rollsOrActivity.options.subject;
    }

    const parentItem = subject?.item || subject?.parent;

    if (subject) {
        const actType = String(subject.type || subject.system?.type?.value || "").toLowerCase();
        const actionType = String(subject.actionType || subject.system?.actionType || "").toLowerCase();
        const className = String(subject.constructor?.name || "");
        const name = String(subject.name || "").toLowerCase();

        const isExplicitSave = actType === "save" 
                            || actionType === "save" 
                            || className.includes("Save")
                            || Boolean(subject.system?.save?.ability);

        if (isExplicitSave) return;

        if (name.includes("trample") || name.includes("stomp")) {
            return;
        }

        if (className === "Item5e" || subject.system?.activities) {
            let activitiesArray = [];
            
            if (subject.system?.activities) {
                if (typeof subject.system.activities.values === "function") {
                    activitiesArray = Array.from(subject.system.activities.values());
                } else if (Array.isArray(subject.system.activities)) {
                    activitiesArray = subject.system.activities;
                } else if (typeof subject.system.activities === "object") {
                    activitiesArray = Object.values(subject.system.activities);
                }
            }

            const hasSaveActivity = activitiesArray.some(act => {
                const type = String(act.type || "").toLowerCase();
                const actClass = String(act.constructor?.name || "");
                return type === "save" || actClass.includes("Save") || Boolean(act.system?.save?.ability);
            });

            const hasAttackActivity = activitiesArray.some(act => {
                const type = String(act.type || "").toLowerCase();
                const actClass = String(act.constructor?.name || "");
                return type === "attack" || actClass.includes("Attack");
            });

            if (hasSaveActivity || (activitiesArray.length > 0 && !hasAttackActivity)) return;
        }
    }

    const hasExactFeature = (featureName) => {
        const lowerKey = featureName.toLowerCase();
        const inItems = actor.items?.some(i => i.name.toLowerCase().includes(lowerKey));
        const inEffects = actor.effects?.some(e => (e.name || e.label || "").toLowerCase().includes(lowerKey));
        return inItems || inEffects;
    };

    const hasLunarForm = hasExactFeature("lunar form") || hasExactFeature("lunar radiance");
    const hasImpFury = hasExactFeature("improved elemental fury");
    const hasBaseFury = !hasImpFury && hasExactFeature("elemental fury");
    
    const isConcentratingOnCME = (() => {
        const cmeEffect = actor.effects?.find(e => {
            const effectName = (e.name || e.label || "").toLowerCase();
            const isConc = e.statuses?.has("concentration") || 
                           effectName.includes("concentrat") || 
                           e.flags?.dnd5e?.isConcentration;
            
            const isCME = effectName.includes("conjure minor elementals") || 
                          effectName.includes("minor elementals") ||
                          e.description?.toLowerCase().includes("conjure minor elementals");
            
            return isConc && isCME;
        });

        if (cmeEffect) return true;

        const isConcentrating = actor.effects?.some(e => e.statuses?.has("concentration") || (e.name || e.label || "").toLowerCase().includes("concentrat"));
        const hasCmeItem = actor.items?.some(i => {
            const name = i.name.toLowerCase();
            return name.includes("conjure minor elementals") || name.includes("minor elementals");
        });

        return isConcentrating && hasCmeItem;
    })();

    if (!hasLunarForm && !hasBaseFury && !hasImpFury && !isConcentratingOnCME) return;

    const lunarLocked = (await actor.getFlag(MODULE_SCOPE, FLAG_LUNAR_LOCK)) ?? false;
    const furyLocked = (await actor.getFlag(MODULE_SCOPE, FLAG_FURY_LOCK)) ?? false;

    const lunarChecked = hasLunarForm && (!lunarLocked || autoCheckReset);
    const furyChecked = (hasBaseFury || hasImpFury) && (!furyLocked || autoCheckReset);

    const savedCmeType = (await actor.getFlag(MODULE_SCOPE, FLAG_CME_TYPE)) || "bludgeoning";
    const savedCmeLevel = (await actor.getFlag(MODULE_SCOPE, FLAG_CME_LEVEL)) || 4;
    const savedFuryType = (await actor.getFlag(MODULE_SCOPE, FLAG_FURY_TYPE)) || "cold";

    const furyDiceCount = hasImpFury ? 2 : 1;

    const selectStyle = "background-color: #1e1e1e; color: #ffffff; border: 1px solid #555555; font-size: 11px; border-radius: 3px; padding: 2px 4px;";
    const optionStyle = "background-color: #1e1e1e; color: #ffffff;";

    const dialogContent = `
        <div style="font-family: sans-serif; padding: 10px; background: #121212; color: #f0f0f0; border-radius: 4px;">
            <p style="font-size: 12px; margin-top: 0; margin-bottom: 10px; color: #bbb; font-style: normal;">Select extra damage options to apply to this hit:</p>
            <div style="display: flex; flex-direction: column; gap: 10px;">
                
                ${hasLunarForm ? `
                    <label style="display: flex; align-items: center; gap: 8px; font-size: 12px; cursor: ${lunarLocked ? 'not-allowed' : 'pointer'}; opacity: ${lunarLocked ? '0.5' : '1'};">
                        <input type="checkbox" id="chk-lunar-form" ${lunarChecked ? 'checked' : ''} ${lunarLocked ? 'disabled' : ''}/>
                        <span><strong>Lunar Form</strong> (2d10 Radiant) ${lunarLocked ? '<strong style="color:#ff6666;">(Used Turn)</strong>' : ''}</span>
                    </label>
                ` : ''}

                ${(hasBaseFury || hasImpFury) ? `
                    <div style="display: flex; flex-direction: column; gap: 4px; opacity: ${furyLocked ? '0.5' : '1'};">
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 12px; cursor: ${furyLocked ? 'not-allowed' : 'pointer'};">
                            <input type="checkbox" id="chk-elemental-fury" ${furyChecked ? 'checked' : ''} ${furyLocked ? 'disabled' : ''}/>
                            <span><strong>${hasImpFury ? 'Improved ' : ''}Elemental Fury</strong> (${furyDiceCount}d8) ${furyLocked ? '<strong style="color:#ff6666;">(Used Turn)</strong>' : ''}</span>
                        </label>
                        <div style="margin-left: 24px; display: flex; align-items: center; gap: 6px;">
                            <span style="font-size: 11px; color: #ccc;">Type:</span>
                            <select id="sel-fury-type" style="${selectStyle}" ${furyLocked ? 'disabled' : ''}>
                                <option value="cold" style="${optionStyle}" ${savedFuryType === "cold" ? "selected" : ""}>Cold</option>
                                <option value="fire" style="${optionStyle}" ${savedFuryType === "fire" ? "selected" : ""}>Fire</option>
                                <option value="lightning" style="${optionStyle}" ${savedFuryType === "lightning" ? "selected" : ""}>Lightning</option>
                                <option value="acid" style="${optionStyle}" ${savedFuryType === "acid" ? "selected" : ""}>Acid</option>
                            </select>
                        </div>
                    </div>
                ` : ''}

                ${isConcentratingOnCME ? `
                    <div style="display: flex; flex-direction: column; gap: 6px; border: 1px solid #2a4d69; background: #0c1824; padding: 8px; border-radius: 4px;">
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 12px; cursor: pointer; color: #70b8ff;">
                            <input type="checkbox" id="chk-cme" checked />
                            <span><strong>Conjure Minor Elementals</strong></span>
                        </label>
                        <div style="margin-left: 24px; display: flex; flex-wrap: wrap; gap: 8px; align-items: center; font-size: 11px; color: #ccc;">
                            <label>Slot Level:
                                <select id="sel-cme-level" style="${selectStyle}">
                                    ${[4,5,6,7,8,9].map(lvl => `<option value="${lvl}" style="${optionStyle}" ${Number(savedCmeLevel) === lvl ? "selected" : ""}>${lvl}th (${(lvl-4)+2}d8)</option>`).join("")}
                                </select>
                            </label>
                            <label>Type:
                                <select id="sel-cme-type" style="${selectStyle}">
                                    <option value="bludgeoning" style="${optionStyle}" ${savedCmeType === "bludgeoning" ? "selected" : ""}>Bludgeoning</option>
                                    <option value="acid" style="${optionStyle}" ${savedCmeType === "acid" ? "selected" : ""}>Acid</option>
                                    <option value="cold" style="${optionStyle}" ${savedCmeType === "cold" ? "selected" : ""}>Cold</option>
                                    <option value="fire" style="${optionStyle}" ${savedFuryType === "fire" ? "selected" : ""}>Fire</option>
                                    <option value="lightning" style="${optionStyle}" ${savedCmeType === "lightning" ? "selected" : ""}>Lightning</option>
                                    <option value="thunder" style="${optionStyle}" ${savedCmeType === "thunder" ? "selected" : ""}>Thunder</option>
                                </select>
                            </label>
                        </div>
                    </div>
                ` : ''}

            </div>
            <div style="margin-top: 14px; border-top: 1px solid #333; padding-top: 8px; display: flex; justify-content: flex-end;">
                <button type="button" id="raug-reset-dialog-locks" style="background: #2b2b2b; color: #c9b07a; border: 1px solid #444; font-size: 11px; padding: 4px 10px; border-radius: 3px; cursor: pointer;">
                    <i class="fas fa-undo"></i> Reset Turn Locks
                </button>
            </div>
        </div>
    `;

    const processRollExecution = async (root) => {
        const applyLunar = root.querySelector("#chk-lunar-form")?.checked ?? false;
        const applyFury = root.querySelector("#chk-elemental-fury")?.checked ?? false;
        const applyCME = root.querySelector("#chk-cme")?.checked ?? false;

        const furyType = root.querySelector("#sel-fury-type")?.value || "cold";
        const cmeLevel = Number(root.querySelector("#sel-cme-level")?.value || 4);
        const cmeType = root.querySelector("#sel-cme-type")?.value || "bludgeoning";

        if (hasBaseFury || hasImpFury) await actor.setFlag(MODULE_SCOPE, FLAG_FURY_TYPE, furyType);
        if (isConcentratingOnCME) {
            await actor.setFlag(MODULE_SCOPE, FLAG_CME_LEVEL, cmeLevel);
            await actor.setFlag(MODULE_SCOPE, FLAG_CME_TYPE, cmeType);
        }

        const lastCtx = window.RAUG_ACTIVE_CONTEXTS?.[window.RAUG_ACTIVE_CONTEXTS.length - 1];
        const isCrit = lastCtx?.isCrit ?? false;
        const multiplier = isCrit ? 2 : 1;

        let extraFormulaParts = [];
        let explanations = [];

        if (applyLunar) {
            const count = 2 * multiplier;
            extraFormulaParts.push(`${count}d10[radiant]`);
            explanations.push(`<strong>${count}d10 Radiant</strong> (Lunar Form)`);
            await actor.setFlag(MODULE_SCOPE, FLAG_LUNAR_LOCK, true);
        }

        if (applyFury) {
            const count = furyDiceCount * multiplier;
            const label = hasImpFury ? "Improved Elemental Fury" : "Elemental Fury";
            const capType = furyType.charAt(0).toUpperCase() + furyType.slice(1);
            extraFormulaParts.push(`${count}d8[${furyType}]`);
            explanations.push(`<strong>${count}d8 ${capType}</strong> (${label})`);
            await actor.setFlag(MODULE_SCOPE, FLAG_FURY_LOCK, true);
        }

        if (applyCME) {
            const baseDice = (cmeLevel - 4) + 2;
            const count = baseDice * multiplier;
            const capType = cmeType.charAt(0).toUpperCase() + cmeType.slice(1);
            extraFormulaParts.push(`${count}d8[${cmeType}]`);
            explanations.push(`<strong>${count}d8 ${capType}</strong> (${cmeLevel}th Level Conjure Minor Elementals)`);
        }

        if (extraFormulaParts.length > 0) {
            const formula = extraFormulaParts.join(" + ");
            
            const DamageRollClass = game.dnd5e?.dice?.DamageRoll || Roll;
            const rollInstance = new DamageRollClass(formula);
            await rollInstance.evaluate();

            const { primaryType, breakdownString, damageDetails } = parseDamageBreakdown(rollInstance);

            let actionName = "Attack";
            if (parentItem?.name && parentItem.name !== actor.name) {
                actionName = parentItem.name;
            } else if (subject?.name && subject.constructor?.name !== "Actor5e" && subject.name !== actor.name) {
                actionName = subject.name;
            }

            const logTitle = `Extra Damage (${actionName})`;

            let cardBody = `
                <div style="font-family: sans-serif; font-size: 12px; line-height: 1.4; color: #191919; font-style: normal;">
                    <div style="font-weight: bold; margin-bottom: 6px; border-bottom: 1px solid #7a2021; padding-bottom: 3px; color: #7a2021; font-size: 13px;">
                        ${logTitle}
                    </div>
                    <ul style="margin: 0; padding-left: 18px; font-style: normal; color: #191919;">
                        ${explanations.map(e => `<li style="font-style: normal;">${e}</li>`).join("")}
                    </ul>
                    ${isCrit ? `<div style="margin-top: 6px; font-weight: bold; color: #b91c1c; font-size: 11px;"><i class="fas fa-bolt"></i> Dice doubled on critical hit!</div>` : ''}
                </div>
            `;

            const targetDescriptors = Array.from(game.user.targets).map(t => {
                const targetActor = t.actor || t.document?.actor;
                return {
                    uuid: targetActor?.uuid || t.document?.uuid,
                    name: targetActor?.name || t.name
                };
            }).filter(t => Boolean(t.uuid));

            const msg = await rollInstance.toMessage({
                speaker: ChatMessage.getSpeaker({ actor }),
                flavor: cardBody,
                flags: {
                    raug: { isExtraDamage: true },
                    dnd5e: {
                        roll: { type: "damage" },
                        targets: targetDescriptors
                    }
                }
            });

            if (msg?.id) {
                logManualDamageContext(
                    actor, 
                    logTitle, 
                    rollInstance.total, 
                    isCrit, 
                    breakdownString || primaryType, 
                    msg.id,
                    damageDetails
                );
            }
        }
    };

    if (foundry.applications?.api?.DialogV2) {
        await foundry.applications.api.DialogV2.wait({
            window: { title: `Extra Damage: ${actor.name}` },
            content: dialogContent,
            buttons: [
                {
                    action: "roll",
                    icon: "fas fa-dice-d20",
                    label: "Roll Extra Damage",
                    default: true,
                    callback: async (event, button, dialog) => {
                        await processRollExecution(dialog.element);
                    }
                },
                {
                    action: "skip",
                    icon: "fas fa-times",
                    label: "Skip"
                }
            ],
            render: (event, dialog) => {
                dialog.element.querySelector("#raug-reset-dialog-locks")?.addEventListener("click", async (e) => {
                    e.preventDefault();
                    await resetExtraDamageTurnLocks(actor);
                    dialog.close();
                    promptExtraDamageIfEligible(actor, rollsOrActivity, true);
                });
            }
        });
    } else {
        const dlg = new Dialog({
            title: `Extra Damage: ${actor.name}`,
            content: dialogContent,
            buttons: {
                roll: {
                    icon: '<i class="fas fa-dice-d20"></i>',
                    label: "Roll Extra Damage",
                    callback: async (html) => {
                        const root = html instanceof HTMLElement ? html : html[0];
                        await processRollExecution(root);
                    }
                },
                skip: {
                    icon: '<i class="fas fa-times"></i>',
                    label: "Skip"
                }
            },
            default: "roll",
            render: (html) => {
                const root = html instanceof HTMLElement ? html : html[0];
                root.querySelector("#raug-reset-dialog-locks")?.addEventListener("click", async (e) => {
                    e.preventDefault();
                    await resetExtraDamageTurnLocks(actor);
                    dlg.close();
                    promptExtraDamageIfEligible(actor, rollsOrActivity, true);
                });
            }
        }, {
            width: 380,
            classes: ["dnd5e2", "sheet", "dark"]
        });
        dlg.render(true);
    }
}