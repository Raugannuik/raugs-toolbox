"use strict";

import { RAUG_MODULE_ID, raugDebugLog, raugRollTotal, raugRollIsCrit } from "./state.js";
import { handleResourceUseViaWrapper } from "./chatBookkeeping.js";
import { promptExtraDamageIfEligible } from "./extraDamageUI.js";
import { saveGlobalContext, loadGlobalContexts } from "./paneTracker.js";

let lastClickedMessageId = null;
let ignorePreUpdateHpUntil = 0;

function getTargetInfo() {
    const rawTargets = Array.from(game.user.targets);
    if (!rawTargets.length) return { id: "", name: "", targets: [] };

    const validTargets = rawTargets.map(t => {
        const actor = t.actor || t.document?.actor;
        if (!actor) return null;

        const cleanUuid = t.document?.uuid || (actor.isToken ? t.document?.uuid : actor.uuid);

        return {
            name: t.name || actor.name,
            img: t.document?.texture?.src || actor.img,
            uuid: cleanUuid,
            ac: actor.system?.attributes?.ac?.value ?? null,
            id: actor.id
        };
    }).filter(Boolean);

    if (!validTargets.length) return { id: "", name: "", targets: [] };

    if (validTargets.length === 1) {
        const target = validTargets[0];
        return { 
            id: target.id, 
            name: target.name,
            targets: validTargets
        };
    }

    return {
        id: validTargets.map(t => t.id).join(","),
        name: validTargets.map(t => t.name).join(", "),
        targets: validTargets
    };
}

function raugRegisterWrapper(target, fn) {
    try {
        libWrapper.register(RAUG_MODULE_ID, target, fn, "WRAPPER");
        raugDebugLog("Registered wrapper:", target);
        return true;
    } catch (err) {
        console.warn("Raug's Toolkit | Failed to register wrapper", target, err);
        return false;
    }
}

function raugRegisterFirstWrapper(targets, fn) {
    for (const target of targets) {
        if (raugRegisterWrapper(target, fn)) return target;
    }
    return null;
}

function raugActivityFromSaveConfig(config) {
    try {
        const el = config?.event?.currentTarget || config?.event?.target;
        const msgEl = el?.closest?.("[data-message-id]");
        const id = msgEl?.dataset?.messageId;
        const msg = id ? game.messages.get(id) : null;
        return msg?.getAssociatedActivity?.() || null;
    } catch (_) {
        return null;
    }
}

function resolveItemName(activity) {
    const item = activity?.item || activity?.parent;
    if (item?.name && item.name.toLowerCase() !== "damage") return item.name;
    if (activity?.name && activity.name.toLowerCase() !== "damage") return activity.name;
    if (activity?.parent?.name) return activity.parent.name;
    return "Unknown Source";
}

function extractTypeFromFormula(formula = "") {
    const flavorMatch = formula.match(/\[([a-zA-Z]+)\]/);
    return flavorMatch?.[1] ? flavorMatch[1].toLowerCase() : "";
}

export function parseDamageBreakdown(rolls, itemName = "", activity = null) {
    const rollArray = Array.isArray(rolls) ? rolls : [rolls];
    const lowerName = itemName.toLowerCase();

    if (lowerName.includes("chill")) return { primaryType: "cold", breakdownString: "Cold", damageDetails: [{ type: "cold", total: raugRollTotal(rolls) }] };
    if (lowerName.includes("warm") || lowerName.includes("fire shield")) return { primaryType: "fire", breakdownString: "Fire", damageDetails: [{ type: "fire", total: raugRollTotal(rolls) }] };

    const typeTotals = {};

    for (const roll of rollArray) {
        if (!roll) continue;

        // Iterate through terms and filter for active terms with results
        const dieTerms = (roll.terms || []).filter(t => (t.results && t.results.length > 0) || Number(t.total) > 0);

        for (const term of dieTerms) {
            let type = (
                term.flavor || 
                term.options?.flavor || 
                term.options?.type || 
                term.options?.damageType || 
                extractTypeFromFormula(term.formula || "")
            )?.toLowerCase();

            // If term flavor is missing, check parent roll options or activity damage type
            if (!type) {
                type = (roll.options?.type || activity?.damage?.types?.values()?.next()?.value || "untyped").toLowerCase();
            }

            const termSum = Array.isArray(term.results) && term.results.length > 0
                ? term.results.reduce((acc, r) => acc + (r.active !== false ? Number(r.result || 0) : 0), 0)
                : Number(term.total || 0);

            if (termSum > 0) {
                typeTotals[type] = (typeTotals[type] || 0) + termSum;
            }
        }

        if (Object.keys(typeTotals).length === 0 && roll.total > 0) {
            const fallbackType = (roll.options?.type || extractTypeFromFormula(roll.formula) || "untyped").toLowerCase();
            typeTotals[fallbackType] = Number(roll.total);
        }
    }

    const types = Object.keys(typeTotals);
    if (types.length === 0) {
        return { primaryType: "untyped", breakdownString: "Untyped", damageDetails: [] };
    }

    const damageDetails = types.map(t => ({ type: t, total: typeTotals[t] }));
    const breakdownString = damageDetails.map(d => `${d.type.charAt(0).toUpperCase() + d.type.slice(1)}: ${d.total}`).join(", ");
    const primaryType = types[0];

    return { primaryType, breakdownString, damageDetails };
}

export async function logAppliedDamage(targetActor, amount, damageType = "", messageId = null) {
    if (!targetActor || isNaN(amount) || amount < 0) return;

    ignorePreUpdateHpUntil = Date.now() + 300;

    await loadGlobalContexts();
    const contexts = window.RAUG_ACTIVE_CONTEXTS || [];
    const appliedVal = Number(amount);

    let targetCtx = null;
    if (messageId) {
        targetCtx = contexts.slice().reverse().find(c => c.messageId === messageId && !c.isApplied);
    }

    if (!targetCtx) {
        targetCtx = contexts.slice().reverse().find(c => !c.isApplied && (c.targetActorId === targetActor.id || !c.targetActorId));
    }

    if (targetCtx) {
        targetCtx.appliedDamage = appliedVal;
        targetCtx.isApplied = true;
        raugDebugLog(`Successfully linked HP change (${appliedVal}) to context ${targetCtx.id}`, targetCtx);
    } else {
        const standaloneAppliedCtx = {
            id: crypto.randomUUID(),
            type: "damage_applied",
            name: "Direct HP Adjustment",
            sourceActorId: "",
            sourceName: "Manual / Direct HP",
            targetActorId: targetActor.id,
            targetName: targetActor.name || "Target",
            originUuid: "",
            messageId: messageId || "",
            timestamp: Date.now(),
            total: appliedVal,
            appliedDamage: appliedVal,
            damageType: damageType || "untyped",
            isApplied: true
        };
        contexts.push(standaloneAppliedCtx);
    }

    await saveGlobalContext(null);
}

export function registerAppliedDamageHooks() {
    document.addEventListener("click", (event) => {
        const btn = event.target?.closest?.("button[data-action='applyDamage'], [data-action='apply-damage'], .apply-damage, [data-action='apply']");
        if (!btn) return;

        const card = btn.closest("[data-message-id]");
        if (card) {
            lastClickedMessageId = card.dataset.messageId || null;
        }
    }, true);

    Hooks.on("dnd5e.applyDamage", (actor, damageData, options) => {
        try {
            const totalApplied = Array.isArray(damageData) 
                ? damageData.reduce((acc, d) => acc + (d.value || 0), 0)
                : Number(damageData || 0);
            const primaryType = Array.isArray(damageData) ? (damageData[0]?.type || "") : "";
            
            const messageId = lastClickedMessageId || options?.message?.id || null;

            logAppliedDamage(actor, totalApplied, primaryType, messageId);
        } catch (err) {
            console.error("Raug's Toolkit | Error tracking dnd5e.applyDamage:", err);
        } finally {
            lastClickedMessageId = null;
        }
    });

    Hooks.on("preUpdateActor", (actor, update, options, userId) => {
        if (game.user.id !== userId) return;
        if (Date.now() < ignorePreUpdateHpUntil) return;

        const hpChange = update.system?.attributes?.hp;
        if (!hpChange || hpChange.value === undefined) return;

        const oldHp = actor.system?.attributes?.hp?.value ?? 0;
        const newHp = hpChange.value;
        const hpDiff = oldHp - newHp;

        if (hpDiff > 0) {
            setTimeout(() => {
                if (Date.now() < ignorePreUpdateHpUntil) return;
                logAppliedDamage(actor, hpDiff, "", lastClickedMessageId);
                lastClickedMessageId = null;
            }, 50);
        }
    });
}

export function logManualDamageContext(actor, sourceName, total, isCrit = false, damageType = "", messageId = "", damageDetails = []) {
    if (!actor || isNaN(total)) return;
    const target = getTargetInfo();

    const rollEntry = {
        total: Number(total),
        isCrit: !!isCrit,
        damageType: damageType,
        damageDetails: damageDetails,
        targetName: target.name
    };

    const ctx = {
        id: crypto.randomUUID(),
        type: "damage_only",
        name: sourceName || "Extra Damage",
        sourceActorId: actor.id || "",
        sourceName: actor.name || "Unknown Source",
        targetActorId: target.id,
        targetName: target.name || "Target",
        originUuid: "",
        messageId: messageId || "",
        timestamp: Date.now(),
        total: Number(total),
        appliedDamage: 0,
        damageRolls: [rollEntry],
        damageType: damageType,
        damageDetails: damageDetails,
        isCrit: !!isCrit,
        isApplied: false
    };

    saveGlobalContext(ctx);
}

export function handleRaugSystemAttackIntercept(activity, rolls) {
    const item = activity?.item || activity?.parent;
    const actor = activity?.actor || item?.actor;
    const roll = Array.isArray(rolls) ? rolls[0] : rolls;
    if (!roll || !actor) return;

    const itemName = resolveItemName(activity);
    const target = getTargetInfo();
    const messageId = activity?.message?.id || activity?.item?.message?.id || "";

    const ctx = {
        id: crypto.randomUUID(),
        type: "attack",
        name: itemName,
        sourceActorId: actor.id || "",
        sourceName: actor.name || "Unknown Attacker",
        targetActorId: target.id,
        targetName: target.name,
        originUuid: item?.uuid || activity?.uuid || "",
        messageId,
        timestamp: Date.now(),
        damageRolls: [],
        resolved: false,
        isMiss: false,
        rollTotal: Number(roll.total ?? NaN),
        isCrit: !!(roll.isCritical || roll.options?.isCritical),
        appliedDamage: 0,
        isApplied: false
    };

    saveGlobalContext(ctx);
}

export async function handleRaugSystemDamageIntercept(activity, rolls) {
    if (
        activity?.flags?.raug?.isManualShieldRoll || 
        activity?.message?.flags?.raug?.isManualShieldRoll ||
        activity?.flags?.raug?.isRaugManualRoll || 
        activity?.message?.flags?.raug?.isRaugManualRoll
    ) return;

    const item = activity?.item || activity?.parent;
    const actor = activity?.actor || item?.actor;

    if (!item && !activity?.item && !activity?.uuid) return;

    const total = raugRollTotal(rolls);
    if (isNaN(total) || activity?.type === "heal") return;

    const isExtraDamage = activity?.flags?.raug?.isExtraDamage || false;

    if (actor && item && !isExtraDamage) {
        promptExtraDamageIfEligible(actor, item).catch(err => {
            console.error("Raug's Toolkit | Error prompting extra damage UI:", err);
        });
    }

    await loadGlobalContexts();

    const isCrit = raugRollIsCrit(rolls);
    const contexts = window.RAUG_ACTIVE_CONTEXTS || [];
    const sourceActorId = actor?.id;
    const originUuid = item?.uuid || activity?.uuid || "";
    const messageId = activity?.message?.id || "";
    
    const itemName = resolveItemName(activity);
    const { primaryType, breakdownString, damageDetails } = parseDamageBreakdown(rolls, itemName, activity);
    const target = getTargetInfo();

    const rollEntry = { 
        total, 
        isCrit, 
        damageType: breakdownString || primaryType, 
        damageDetails, 
        targetName: target.name 
    };

    if (isExtraDamage) {
        const extraCtx = {
            id: crypto.randomUUID(),
            type: "damage_only",
            name: `${itemName} (Extra Damage)`,
            sourceActorId: sourceActorId || "",
            sourceName: actor?.name || "Unknown Source",
            targetActorId: target.id,
            targetName: target.name,
            originUuid,
            messageId,
            timestamp: Date.now(),
            total,
            appliedDamage: 0,
            damageRolls: [rollEntry],
            damageType: breakdownString || primaryType,
            damageDetails,
            isCrit,
            isApplied: false
        };
        await saveGlobalContext(extraCtx);
        return;
    }

    if (messageId && contexts.some(c => c.messageId === messageId)) {
        return;
    }

    if (activity?.type === "save") {
        for (let i = contexts.length - 1; i >= 0; i--) {
            const ctx = contexts[i];
            if (ctx.type !== "spell" || ctx.isApplied) continue;
            if (originUuid && ctx.originUuid !== originUuid) continue;
            if (sourceActorId && ctx.sourceActorId && ctx.sourceActorId !== sourceActorId) continue;
            ctx.damageRolls = [rollEntry];
            ctx.damageDetails = damageDetails;
            if (messageId) ctx.messageId = messageId;
            await saveGlobalContext(null);
            return;
        }

        const newSpellCtx = {
            id: crypto.randomUUID(),
            type: "spell",
            name: itemName,
            sourceActorId: sourceActorId || "",
            sourceName: actor?.name || "Unknown Source",
            targetActorId: target.id,
            targetName: target.name,
            originUuid,
            messageId,
            timestamp: Date.now(),
            dc: Number(activity?.save?.dc?.value ?? 10),
            onSave: activity?.damage?.onSave || "half",
            saves: [],
            damageRolls: [rollEntry],
            damageDetails,
            savesWaiting: true,
            appliedDamage: 0,
            isApplied: false
        };

        saveGlobalContext(newSpellCtx);
        return;
    }

    const lowerName = itemName.toLowerCase();
    const isShieldReaction = lowerName.includes("fire shield") || lowerName.includes("chill") || lowerName.includes("warm");

    if (!isShieldReaction) {
        for (let i = contexts.length - 1; i >= 0; i--) {
            const ctx = contexts[i];
            if (ctx.type !== "attack" || ctx.resolved || ctx.isApplied) continue;
            if (sourceActorId && ctx.sourceActorId && ctx.sourceActorId !== sourceActorId) continue;
            if (originUuid && ctx.originUuid && ctx.originUuid !== originUuid) continue;
            
            ctx.damageRolls = [rollEntry];
            ctx.damageDetails = damageDetails;
            ctx.total = total;
            ctx.resolved = true;
            if (messageId) ctx.messageId = messageId;
            await saveGlobalContext(null);
            return;
        }
    }

    const standaloneCtx = {
        id: crypto.randomUUID(),
        type: "damage_only",
        name: itemName,
        sourceActorId: sourceActorId || "",
        sourceName: actor?.name || "Unknown Source",
        targetActorId: target.id,
        targetName: target.name,
        originUuid,
        messageId,
        timestamp: Date.now(),
        total,
        appliedDamage: 0,
        damageRolls: [rollEntry],
        damageType: breakdownString || primaryType,
        damageDetails,
        isCrit,
        isApplied: false
    };

    saveGlobalContext(standaloneCtx);
}

export function handleRaugSystemSaveActivityUse(activity) {
    const item = activity?.item || activity?.parent;
    const actor = activity?.actor || item?.actor;
    const itemName = resolveItemName(activity);
    const target = getTargetInfo();

    const dc = Number(activity?.save?.dc?.value ?? actor?.system?.attributes?.spell?.dc ?? 10);
    const spellCtx = {
        id: crypto.randomUUID(),
        type: "spell",
        name: itemName,
        sourceActorId: actor?.id || "",
        sourceName: actor?.name || "Unknown Source",
        targetActorId: target.id,
        targetName: target.name,
        originUuid: item?.uuid || activity?.uuid || "",
        messageId: activity?.message?.id || "",
        timestamp: Date.now(),
        dc,
        onSave: activity?.damage?.onSave || "half",
        saves: [],
        damageRolls: [],
        savesWaiting: true,
        appliedDamage: 0,
        isApplied: false
    };

    saveGlobalContext(spellCtx);
}

export async function handleRaugSystemSaveIntercept(actor, config, rolls) {
    const total = raugRollTotal(rolls);
    if (isNaN(total)) return;

    await loadGlobalContexts();

    const activity = raugActivityFromSaveConfig(config);
    const originUuid = activity?.item?.uuid || activity?.uuid || "";
    const contexts = window.RAUG_ACTIVE_CONTEXTS || [];
    let ctx = null;

    if (originUuid) {
        for (let i = contexts.length - 1; i >= 0; i--) {
            if (contexts[i].type === "spell" && contexts[i].originUuid === originUuid) {
                ctx = contexts[i];
                break;
            }
        }
    }
    if (!ctx) {
        for (let i = contexts.length - 1; i >= 0; i--) {
            if (contexts[i].type === "spell" && contexts[i].savesWaiting) {
                ctx = contexts[i];
                break;
            }
        }
    }
    if (!ctx) return;

    const dc = Number.isFinite(Number(config?.target)) ? Number(config.target) : (ctx.dc || 10);
    ctx.dc = dc;
    const passed = total >= dc;
    ctx.saves.push({ actorName: actor?.name || "Target", passed });

    await saveGlobalContext(null);
}

export async function handleConsumableUseViaWrapper(actor, item, result) {
    if (!actor || !item) return;

    try {
        await handleResourceUseViaWrapper(actor, item, result);
    } catch (err) {
        console.error("Raug's Toolkit | Error processing consumable wrapper handle", err);
    }
}

export function registerAllWrappers() {
    try {
        raugRegisterFirstWrapper([
            "CONFIG.DND5E.activityTypes.attack.documentClass.prototype.rollAttack",
            "dnd5e.documents.activity.AttackActivity.prototype.rollAttack"
        ], async function (wrapped, ...args) {
            const result = await wrapped.apply(this, args);
            if (result) handleRaugSystemAttackIntercept(this, result);
            return result;
        });

        const damageTypes = Object.keys(CONFIG.DND5E?.activityTypes || { attack: 1, save: 1, damage: 1, utility: 1 });
        let wrappedDamage = false;
        for (const type of damageTypes) {
            const cls = CONFIG.DND5E?.activityTypes?.[type]?.documentClass;
            if (typeof cls?.prototype?.rollDamage !== "function") continue;
            const ok = raugRegisterWrapper(
                `CONFIG.DND5E.activityTypes.${type}.documentClass.prototype.rollDamage`,
                async function (wrapped, ...args) {
                    const result = await wrapped.apply(this, args);
                    if (result) handleRaugSystemDamageIntercept(this, result);
                    return result;
                }
            );
            wrappedDamage = wrappedDamage || ok;
        }
        if (!wrappedDamage) {
            raugRegisterFirstWrapper([
                "dnd5e.documents.activity.AttackActivity.prototype.rollDamage",
                "dnd5e.documents.activity.SaveActivity.prototype.rollDamage"
            ], async function (wrapped, ...args) {
                const result = await wrapped.apply(this, args);
                if (result) handleRaugSystemDamageIntercept(this, result);
                return result;
            });
        }

        raugRegisterWrapper(
            "CONFIG.DND5E.activityTypes.save.documentClass.prototype.use",
            async function (wrapped, ...args) {
                const result = await wrapped.apply(this, ...args);
                if (result !== undefined && result !== false && result !== null) {
                    handleRaugSystemSaveActivityUse(this);
                }
                return result;
            }
        );

        raugRegisterFirstWrapper([
            "CONFIG.Actor.documentClass.prototype.rollSavingThrow",
            "dnd5e.documents.Actor5e.prototype.rollSavingThrow"
        ], async function (wrapped, config = {}, dialog = {}, message = {}) {
            const result = await wrapped.apply(this, [config, dialog, message]);
            if (result) handleRaugSystemSaveIntercept(this, config, result);
            return result;
        });

        registerAppliedDamageHooks();

        console.log("Raug's Toolkit | Core System Intercepts Registered successfully during Ready phase.");
    } catch (err) {
        console.error("Raug's Toolkit | Failed to register system method wrappers on Ready", err);
    }
}