// scripts/modules/paneMacros.js
"use strict";

export function buildMacroPane(actor, container) {
    if (!container) return;
    container.innerHTML = `
        <strong style="color:#c9b07a; font-size:11px; display:block; margin-bottom:6px; font-weight:bold;"><i class="fas fa-terminal"></i> Hotbar Macro Library</strong>
        <div id="raug-macro-list" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap:6px; background:#1a1a1a; padding:6px; border:1px solid #444; border-radius:4px; min-height:60px;">
            <div id="raug-macro-empty" style="grid-column:1/-1; text-align:center; color:#666; font-size:11px; padding:12px;">Drag macros here to pin.</div>
        </div>
    `;
    const list = container.querySelector("#raug-macro-list");
    let flags = actor.getFlag("world", "raugMacroTab") || { macros: [] };

    const renderMacroEntry = (macro) => {
        if (!macro) return;
        const placeholder = container.querySelector("#raug-macro-empty"); if (placeholder) placeholder.remove();
        const entry = document.createElement("button"); entry.type = "button";
        entry.style.cssText = "background:#262626; border:1px solid #444; color:#e6d9b6; font-size:11px; padding:4px; border-radius:4px; cursor:pointer; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;";
        entry.textContent = macro.name;
        entry.onclick = () => macro.execute();
        entry.oncontextmenu = async (ev) => {
            ev.preventDefault(); flags.macros = flags.macros.filter(m => m !== macro.id);
            await actor.setFlag("world", "raugMacroTab", flags); entry.remove();
        };
        list.appendChild(entry);
    };

    flags.macros.forEach(id => { const m = game.macros.get(id); if (m) renderMacroEntry(m); });
    list.addEventListener("dragover", ev => ev.preventDefault());
    list.addEventListener("drop", async ev => {
        ev.preventDefault();
        try {
            const raw = ev.dataTransfer.getData("text/plain"); if (!raw) return;
            const data = JSON.parse(raw);
            if (data.type !== "Macro" && data.type !== "macro") return;
            const mDoc = game.macros.get(data.id || data._id);
            if (mDoc && !flags.macros.includes(mDoc.id)) {
                flags.macros.push(mDoc.id); await actor.setFlag("world", "raugMacroTab", flags);
                renderMacroEntry(mDoc);
            }
        } catch (_) {}
    });
}