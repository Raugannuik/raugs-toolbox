// scripts/modules/wildShapeUI.js
"use strict";

export async function handleWildShapeUseViaWrapper(wrapped, item, args) {
    const actor = item.actor;
    const wsItem = actor.items.find(i => i.name.toLowerCase().includes("wild shape")) || item;

    const uses = wsItem.system?.uses || {};
    const maxUses = uses.max || 0;
    const curUses = uses.value ?? 0;
    const curSpent = uses.spent ?? (maxUses - curUses);

    // 1. Open RAUG Visual Dialog
    const result = await renderWildShapeDialog(actor, wsItem, curUses, maxUses);
    if (!result) return null; // Player cancelled

    let wasResurgence = false;
    let spentSlotLevel = 0;
    let slotKey = null;

    // 2. Handle Resurgence Resource Swap
    if (result.action === "resurgence") {
        wasResurgence = true;
        spentSlotLevel = result.slotLevel;
        slotKey = result.slotKey;

        const slotVal = foundry.utils.getProperty(actor.system, `spells.${slotKey}.value`) || 0;
        await actor.update({ [`system.spells.${slotKey}.value`]: Math.max(0, slotVal - 1) });

        // Credit 1 charge back to Wild Shape so standard item consumption balances out
        await wsItem.update({ "system.uses.spent": Math.max(0, curSpent - 1) });
    }

    // 3. Moon Druid Temp HP Calculation (2024 PHB)
    const druidClass = actor.itemTypes.class.find(c => c.name.toLowerCase().includes("druid"));
    const druidLevel = druidClass ? (druidClass.system.levels || 0) : 0;
    const tempHP = druidLevel * 3;

    if (tempHP > (actor.system.attributes?.hp?.temp || 0)) {
        await actor.update({ "system.attributes.hp.temp": tempHP });
    }

    // 4. Hook into chat message creation BEFORE executing standard rollout
    const remaining = Math.max(0, curUses - (wasResurgence ? 0 : 1));
    const hookId = Hooks.once("createChatMessage", async (msg) => {
        if (msg.speaker?.actor === actor.id || msg.actor?.id === actor.id) {
            await appendResurgenceNoteToCard(actor, msg, wasResurgence, spentSlotLevel, slotKey, remaining, maxUses);
        }
    });

    // 5. Run standard item usage roll
    const useResult = await wrapped.apply(item, args);

    // Safety fallback cleanup in case no message was created
    setTimeout(() => Hooks.off("createChatMessage", hookId), 3000);

    return useResult;
}

async function renderWildShapeDialog(actor, wsItem, curUses, maxUses) {
    const spells = actor.system.spells || {};
    const availableSlots = [];

    for (let l = 1; l <= 9; l++) {
        const slot = spells[`spell${l}`];
        if (slot && slot.max > 0 && slot.value > 0) {
            availableSlots.push({ key: `spell${l}`, level: l, label: `Level ${l}`, value: slot.value, max: slot.max });
        }
    }

    if (spells.pact && spells.pact.max > 0 && spells.pact.value > 0) {
        availableSlots.push({ key: "pact", level: spells.pact.level, label: `Pact Lv.${spells.pact.level}`, value: spells.pact.value, max: spells.pact.max });
    }

    const badgeColor = curUses > 1 ? "#2b8a3e" : curUses === 1 ? "#d97706" : "#d93838";

    const dialogContent = `
    <div style="font-family: sans-serif; color: #d6d6d6; background: #1a1a1a; padding: 10px; border-radius: 4px; border: 1px solid rgba(201,176,122,0.4);">
        <div style="display: flex; align-items: center; border-bottom: 1px solid #444; padding-bottom: 8px; margin-bottom: 10px;">
            <img src="${wsItem.img}" style="width: 36px; height: 36px; margin-right: 10px; border: 1px solid #c9b07a; border-radius: 4px; object-fit: cover;"/>
            <div>
                <h3 style="margin: 0; color: #c9b07a; font-size: 16px;">Wild Shape Hub</h3>
                <span style="font-size: 10px; color: #888;">RAUG Utility • 2024 PHB Engine</span>
            </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.05); padding: 6px 10px; border-radius: 4px; margin-bottom: 12px; border: 1px solid rgba(255,255,255,0.1);">
            <span style="font-weight: bold; font-size: 12px;">Charges Remaining:</span>
            <span style="padding: 2px 8px; border-radius: 3px; font-weight: bold; font-size: 12px; background: rgba(0,0,0,0.3); color: ${badgeColor}; border: 1px solid ${badgeColor};">
                ${curUses} / ${maxUses}
            </span>
        </div>

        ${curUses > 0 ? `
            <button type="button" class="raug-ws-btn-direct" style="width: 100%; background: #2b8a3e; color: #fff; border: none; padding: 8px; font-weight: bold; border-radius: 4px; cursor: pointer; margin-bottom: 10px;">
                Use Wild Shape Charge (${curUses - 1} Remaining)
            </button>
        ` : `
            <div style="background: rgba(217, 56, 56, 0.15); border-left: 3px solid #d93838; padding: 8px; margin-bottom: 12px; border-radius: 0 4px 4px 0; font-size: 11px;">
                <strong style="color: #f87171;">0 Wild Shape Charges Available</strong><br/>
                Expend a spell slot via Wild Resurgence to gain 1 charge immediately.
            </div>
        `}

        <details ${curUses === 0 ? "open" : ""} style="border: 1px solid rgba(201,176,122,0.2); border-radius: 4px; padding: 6px; background: rgba(0,0,0,0.2);">
            <summary style="font-weight: bold; font-size: 12px; cursor: pointer; color: #c9b07a; display: flex; justify-content: space-between; align-items: center;">
                <span>Wild Resurgence (Slot Conversion) ${availableSlots.length === 0 ? '<span style="color:#f87171;">(No Slots)</span>' : ''}</span>
                
                <span title="Wild Resurgence (2024 PHB)&#10;• If you have no uses of Wild Shape left, you can give yourself one use by expending a spell slot (no action required).&#10;• Alternatively, once per Long Rest, if you have no spell slots left, you can expend 1 Wild Shape charge to gain one 1st-level spell slot." style="color: #888; font-size: 10px; font-weight: normal; border: 1px solid #555; padding: 1px 5px; border-radius: 3px; background: rgba(0,0,0,0.4);">
                    <i class="fas fa-book"></i> Rule
                </span>
            </summary>

            <div style="margin-top: 8px; font-size: 11px;">
                <div style="background: rgba(201,176,122,0.08); border-left: 2px solid #c9b07a; padding: 6px; margin-bottom: 8px; font-size: 10px; color: #aaa; line-height: 1.3;">
                    <strong style="color: #c9b07a;">2024 PHB Rule:</strong> If you have no Wild Shape uses left, expend any 1st+ level spell slot to gain 1 charge (no action required).
                </div>

                ${availableSlots.length > 0 ? `
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px; margin-top: 6px;">
                        ${availableSlots.map(s => `
                            <button type="button" class="raug-ws-btn-resurgence" data-key="${s.key}" data-level="${s.level}" style="background: #2a2a2a; color: #c9b07a; border: 1px solid rgba(201,176,122,0.3); padding: 6px; border-radius: 3px; cursor: pointer; font-size: 11px;">
                                ${s.label} (${s.value}/${s.max})
                            </button>
                        `).join("")}
                    </div>
                ` : `
                    <p style="margin: 4px 0; color: #f87171;">No spell slots available.</p>
                `}
            </div>
        </details>
    </div>
    `;

    return new Promise((resolve) => {
        const dialog = new Dialog({
            title: "Wild Shape Hub",
            content: dialogContent,
            buttons: {},
            render: (html) => {
                html.find(".raug-ws-btn-direct").click(() => {
                    resolve({ action: "direct" });
                    dialog.close();
                });

                html.find(".raug-ws-btn-resurgence").click((e) => {
                    const btn = $(e.currentTarget);
                    resolve({
                        action: "resurgence",
                        slotKey: btn.data("key"),
                        slotLevel: btn.data("level")
                    });
                    dialog.close();
                });
            },
            close: () => resolve(null)
        });
        dialog.render(true);
    });
}

function getOrdinalSuffix(n) {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

async function appendResurgenceNoteToCard(actor, targetMessage, wasResurgence, slotLevel, slotKey, remaining, maxUses) {
    if (!targetMessage) return;

    const lineStyle = "font-size: 11px; color: #191813; font-weight: 600; line-height: 1.3;";
    let resurgenceDetails = "";

    if (wasResurgence && slotKey) {
        const slotData = foundry.utils.getProperty(actor.system, `spells.${slotKey}`) || { value: 0, max: 0 };
        const ordinalLevel = getOrdinalSuffix(slotLevel);
        
        resurgenceDetails = `
            <div>Expended a Level ${slotLevel} spell slot to Wild Shape</div>
            <div style="color: #444; font-weight: 500; font-size: 10px;">${ordinalLevel} level Spell slots remaining: ${slotData.value}/${slotData.max}</div>
        `;
    }

    const ledgerNote = `
        <div style="margin-top: 4px; padding-top: 4px; border-top: 1px solid rgba(0,0,0,0.15); ${lineStyle}">
            ${resurgenceDetails}
            <div style="color: #666; font-weight: normal; font-size: 10px;">${remaining}/${maxUses} Wild Shapes remaining</div>
        </div>
    `;

    await targetMessage.update({ content: targetMessage.content + ledgerNote });
}