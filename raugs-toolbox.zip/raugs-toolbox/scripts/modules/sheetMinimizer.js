// scripts/modules/sheetMinimizer.js
"use strict";

// Set your desired fixed minimum minimized width here
const MIN_SHEET_WIDTH = 460; 

function injectMinimizerStyles() {
    if (document.getElementById("raug-minimizer-styles")) return;

    const style = document.createElement("style");
    style.id = "raug-minimizer-styles";
    style.innerHTML = `
        /* Override core Foundry 200px minimized window constraint */
        .window-app.actor.minimized,
        .application.actor.minimized {
            width: ${MIN_SHEET_WIDTH}px !important;
            min-width: ${MIN_SHEET_WIDTH}px !important;
            overflow: visible !important;
        }

        .window-app.actor.minimized .window-content,
        .application.actor.minimized .window-content {
            overflow: visible !important;
        }

        /* Prevent button text wrapping so buttons maintain their natural layout */
        .raug-footer-tabs .raug-subtab-btn {
            white-space: nowrap !important;
        }
    `;
    document.head.appendChild(style);
}

function enforceMinimizedWidth(html) {
    injectMinimizerStyles();

    const windowApp = html[0]?.closest(".window-app, .application") || html[0];
    if (!windowApp) return;

    if (windowApp.classList.contains("minimized")) {
        windowApp.style.setProperty("width", `${MIN_SHEET_WIDTH}px`, "important");
        windowApp.style.setProperty("min-width", `${MIN_SHEET_WIDTH}px`, "important");
    }
}

// Hooks
Hooks.on("renderActorSheet", (app, html) => enforceMinimizedWidth(html));
Hooks.on("renderActorSheetV2", (app, html) => enforceMinimizedWidth(html));

Hooks.on("minimizeApplication", (app, html) => {
    injectMinimizerStyles();
    const windowApp = html[0]?.closest(".window-app, .application") || html[0];
    if (!windowApp) return;

    windowApp.style.setProperty("width", `${MIN_SHEET_WIDTH}px`, "important");
    windowApp.style.setProperty("min-width", `${MIN_SHEET_WIDTH}px`, "important");
    windowApp.style.setProperty("overflow", "visible", "important");
});

Hooks.on("unminimizeApplication", (app, html) => {
    const windowApp = html[0]?.closest(".window-app, .application") || html[0];
    if (windowApp) {
        windowApp.style.minWidth = "";
        if (app.position?.width) {
            windowApp.style.width = `${app.position.width}px`;
        } else {
            windowApp.style.width = "";
        }
    }
});